<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");

if ($CPMlevel == 4) {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="3" width="98%">
<form method="post" action="cp_home.php?mode=best&type=insert_data">
		<td class="cat" colspan="4"><nobr>'.$lang['admin']['best_options'].'</nobr></td>
	</tr>
	 <tr class="fixed">
	 </td><td class="list"><nobr>'.$lang['admin']['description'].'</nobr>
	  <td class="userdetails_data"><input type="text" name="best_t" size="40" value="'.$best_t.'">
	  <td class="list"><nobr>'.$lang['add_cat_forum']['active'].'</nobr></td>
	  <td class="userdetails_data"><input type="radio" value="1" name="best" '.check_radio($best, "1").'>'.$lang['add_cat_forum']['no'].'&nbsp;&nbsp;
    	<input type="radio" value="0" name="best" '.check_radio($best, "0").'>'.$lang['add_cat_forum']['yes'].'</td>
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['member_top_title'].'</nobr>
		<td class="list"><input type="text" name="best_mem_t" size="40" value="'.$best_mem_t.'">
		<td class="list"><nobr>'.$lang['admin']['member_top_number'].'</nobr>
		<td class="list"><input type="text" name="best_mem" size="10" value="'.$best_mem.'">

	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr></nobr>'.$lang['admin']['topic_top_title'].'</td>
		<td class="middle"><input type="text" name="best_topic_t" size="40" value="'.$best_topic_t.'">
				<td class="list"><nobr>'.$lang['admin']['topic_top_number'].'</nobr></td>
		<td class="middle"><input type="text" name="best_topic" size="10" value="'.$best_topic.'">
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['mod_top_title'].'</nobr></td>
		<td class="middle"><input type="text" name="best_mod_t" size="40" value="'.$best_mod_t.'">
				<td class="list"><nobr>'.$lang['admin']['mod_top_number'].'</nobr></td>
		<td class="middle"><input type="text" name="best_mod" size="10" value="'.$best_mod.'">
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['forum_top_title'].'</nobr></td>
		<td class="middle"><input type="text" name="best_frm_t" size="40" value="'.$best_frm_t.'">
			<td class="list"><nobr>'.$lang['admin']['forum_top_number'].'</nobr></td>
		<td class="middle"><input type="text" name="best_frm" size="10" value="'.$best_frm.'">
	</tr>


 	<tr class="fixed">
		<td align="middle" colspan="4"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {
updata_mysql("BEST", $_POST['best']);
updata_mysql("BEST_MEM", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_mem'])));
updata_mysql("BEST_TOPIC", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_topic'])));
updata_mysql("BEST_MOD", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_mod'])));
updata_mysql("BEST_FRM", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_frm'])));

updata_mysql("BEST_T", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_t'])));
updata_mysql("BEST_MEM_T", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_mem_t'])));
updata_mysql("BEST_TOPIC_T", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_topic_t'])));
updata_mysql("BEST_MOD_T", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_mod_t'])));
updata_mysql("BEST_FRM_T", htmlspecialchars(DBi::$con->real_escape_string($_POST['best_frm_t'])));


                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=best">
                           <a href="cp_home.php?mode=best">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
 }
else {
    go_to("index.php");
}
?>