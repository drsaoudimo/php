<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");
require_once("./engine/function.php");

if ($CPMlevel == 4) {

$question = icons($icon_question, $lang['admin']['click_here_to_know_what_this'], "");

if ($method == "") {

 if ($type == "") {
echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=option&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['edit_forum_options'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['forum_title'].'</nobr></td>
		<td class="middle"><input type="text" name="forum_name" size="40" value="'.$forum_title.'"></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['forum_title2'].'</nobr></td>
		<td class="middle"><input type="text" name="forum_name2" size="40" value="'.$forum_title2.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['site_url'].'</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="site_address" size="40" value="'.$site_name.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['site_url2'].'</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="site_address2" size="40" value="'.$site_name2.'"></td>
	</tr>	
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['admin_email'].'</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="admin_email" size="40" value="'.$admin_email.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['forum_copyright'].'</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="copy_right" size="40" value="'.$copy_right.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['images_folder'].'</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="image_folder" size="40" value="'.$image_folder.'"></td>
	</tr>
<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['forum_description'].'</nobr></td>
		<td class="middle"><input type="text" name="meta" size="40" value="'.$Meta.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['meta_tag'].'</nobr></td>
		<td class="middle"><input type="text" name="key" size="40" value="'.$KeyWords.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['banwords'].'</nobr></td>
		<td class="middle"><input type="text" name="ban_words" size="40" value="'.$BanWords.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['twitter_page'].'</nobr></td>
		<td class="middle"><input type="text" name="twitter" size="40" value="'.$twitter.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>CONSUMER_KEY - Twitter</nobr></td>
		<td class="middle"><input type="text" name="consumer_key" size="40" value="'.$consumer_key.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>CONSUMER_SECRET - Twitter</nobr></td>
		<td class="middle"><input type="text" name="consumer_secret" size="40" value="'.$consumer_secret.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>OAUTH_TOKEN - Twitter</nobr></td>
		<td class="middle"><input type="text" name="oauth_token" size="40" value="'.$oauth_token.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>OAUTH_SECRET - Twitter</nobr></td>
		<td class="middle"><input type="text" name="oauth_secret" size="40" value="'.$oauth_secret.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>LOGIN KEY - bit.ly</nobr></td>
		<td class="middle"><input type="text" name="login_key" size="40" value="'.$login_key.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>APP KEY - bit.ly</nobr></td>
		<td class="middle"><input type="text" name="app_key" size="40" value="'.$app_key.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>'.$lang['add_cat_forum']['hashtag'].'</nobr></td>
		<td class="middle"><font color="black">#</font> <input type="text" name="forum_hashtag" size="38" value="'.$forum_hashtag.'"></td>
</tr>
<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['forum_logo_url'].'</nobr></td>
		<td class="middle"><input type="text" name="logos" size="40" value="'.$logos.'"></td>
</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['admin_user_name'].'</nobr></td>
		<td class="middle"><input type="text" dir="rtl" name="admin_user_name" size="40" value="'.$admin_user_name.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['admin_name'].'</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="admin_folder" size="40" value="'.$admin_folder.'" class="only_alpha_num"></td>
<script type="text/javascript" src="./javascript/menu.js"></script>
	</tr>	
<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['change_url'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="0" name="seo" '.check_radio($seo, "0").'>'.$lang['add_cat_forum']['no'].'&nbsp;&nbsp;
        <input type="radio" value="1" name="seo" '.check_radio($seo, "1").'>'.$lang['add_cat_forum']['yes'].'</td>
	</tr>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';

 }

 if ($type == "insert_data") {

$Admin_ForumTitle = htmlspecialchars(DBi::$con->real_escape_string($_POST["forum_name"]));
$Admin_ForumTitle2 = htmlspecialchars(DBi::$con->real_escape_string($_POST["forum_name2"]));
$Admin_SiteAddress = htmlspecialchars(DBi::$con->real_escape_string($_POST["site_address"]));
$Admin_SiteAddress2 = htmlspecialchars(DBi::$con->real_escape_string($_POST["site_address2"]));
$Admin_CopyRight = htmlspecialchars(DBi::$con->real_escape_string($_POST["copy_right"]));
$Admin_ImageFolder = htmlspecialchars(DBi::$con->real_escape_string($_POST["image_folder"]));
$Admin_AdminFolder = @eregi(htmlspecialchars(DBi::$con->real_escape_string($_POST["admin_folder"])));
$Admin_AdminEmail = htmlspecialchars(DBi::$con->real_escape_string($_POST["admin_email"]));
$Admin_Seo = htmlspecialchars(DBi::$con->real_escape_string($_POST["seo"]));
$Admin_Meta = htmlspecialchars(DBi::$con->real_escape_string($_POST["meta"]));
$Admin_Key = htmlspecialchars(DBi::$con->real_escape_string($_POST["key"]));
$Admin_Ban_Words = htmlspecialchars(DBi::$con->real_escape_string($_POST["ban_words"]));
$twitter = htmlspecialchars(DBi::$con->real_escape_string($_POST["twitter"]));
$admin_user_name = htmlspecialchars(DBi::$con->real_escape_string($_POST["admin_user_name"]));
updata_mysql("logos", $_POST['logos']);
$Admin_AdminFolder = htmlspecialchars(DBi::$con->real_escape_string($_POST["admin_folder"]));
$consumer_key = htmlspecialchars(DBi::$con->real_escape_string($_POST["consumer_key"]));
$consumer_secret = htmlspecialchars(DBi::$con->real_escape_string($_POST["consumer_secret"]));
$oauth_token = htmlspecialchars(DBi::$con->real_escape_string($_POST["oauth_token"]));
$oauth_secret = htmlspecialchars(DBi::$con->real_escape_string($_POST["oauth_secret"]));
$login_key = htmlspecialchars(DBi::$con->real_escape_string($_POST["login_key"]));
$app_key = htmlspecialchars(DBi::$con->real_escape_string($_POST["app_key"]));
$forum_hashtag = htmlspecialchars(DBi::$con->real_escape_string($_POST["forum_hashtag"]));


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("FORUM_TITLE", $Admin_ForumTitle);
updata_mysql("FORUM_TITLE2", $Admin_ForumTitle2);
updata_mysql("SITE_ADDRESS", $Admin_SiteAddress);
updata_mysql("SITE_ADDRESS2", $Admin_SiteAddress2);
updata_mysql("COPY_RIGHT", $Admin_CopyRight);
updata_mysql("IMAGE_FOLDER", $Admin_ImageFolder);
updata_mysql("ADMIN_EMAIL", $Admin_AdminEmail);
updata_mysql("FORUM_SEO", $Admin_Seo);
updata_mysql("FORUM_META", $Admin_Meta);
updata_mysql("FORUM_KEY", $Admin_Key);
updata_mysql("FORUM_BANWORDS", $Admin_Ban_Words);
updata_mysql("ADMIN_FOLDER", $Admin_AdminFolder);
updata_mysql("TWITTER", $twitter);
updata_mysql("CONSUMER_KEY", $consumer_key);
updata_mysql("CONSUMER_SECRET", $consumer_secret);
updata_mysql("OAUTH_TOKEN", $oauth_token);
updata_mysql("OAUTH_SECRET", $oauth_secret);
updata_mysql("LOGIN_KEY", $login_key);
updata_mysql("APP_KEY", $app_key);
updata_mysql("FORUM_HASHTAG", $forum_hashtag);
updata_mysql("ADMIN_USER_NAME", $admin_user_name);
rename($admin_folder.".php", $Admin_AdminFolder.".php");

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=option">
                           <a href="cp_home.php?mode=option">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}

if ($method == "other") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=option&method=other&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="5"><nobr>'.$lang['admin']['general_options'].'</nobr></td>
	</tr>
	 	<tr class="fixed">
			<td class="list"><nobr>'.$lang['admin']['active_portal'].'</nobr></td>
			<td class="list"><input type="radio" value="1" name="active_portal" '.check_radio($active_portal, "1").'>'.$lang['add_cat_forum']['yes'].'</td>
			<td class="list" colSpan="3"><input type="radio" value="0" name="active_portal" '.check_radio($active_portal, "0").'>'.$lang['add_cat_forum']['no'].'</td>
		</tr>	
	 	<tr class="fixed">
			<td class="list"><nobr>'.$lang['admin']['active_show_hkma_sitemap'].'</nobr></td>
			<td class="list"><input type="radio" value="1" name="show_hkma_sitemap" '.check_radio($show_hkma_sitemap, "1").'>'.$lang['add_cat_forum']['yes'].'</td>
			<td class="list" colSpan="3"><input type="radio" value="0" name="show_hkma_sitemap" '.check_radio($show_hkma_sitemap, "0").'>'.$lang['add_cat_forum']['no'].'</td>
		</tr>			
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['register_options'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="1" name="register_waitting" '.check_radio($register_waitting, "1").'>'.$lang['admin']['admin_approve'].'&nbsp;&nbsp;</td>
        <td class="userdetails_data"> <input type="radio" value="2" name="register_waitting" '.check_radio($register_waitting, "2").'>'.$lang['admin']['close'].'</td>
		<td class="userdetails_data"><input type="radio" value="0" name="register_waitting" '.check_radio($register_waitting, "0").'>'.$lang['admin']['open'].'&nbsp;&nbsp;</td>
		<td class="userdetails_data"><input type="radio" value="3" name="register_waitting" '.check_radio($register_waitting, "3").'>'.$lang['admin']['admin_approve_email'].'&nbsp;&nbsp;</td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['show_medals_in_posts'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="1" name="show_medals_in_posts" '.check_radio($show_medals_in_posts, "1").'>'.$lang['admin']['show_medal_title'].'&nbsp;&nbsp;</td>
        <td class="userdetails_data"><input type="radio" value="2" name="show_medals_in_posts" '.check_radio($show_medals_in_posts, "2").'>'.$lang['admin']['show_medal_photo'].'</td>
		<td class="userdetails_data" colspan="2"><input type="radio" value="0" name="show_medals_in_posts" '.check_radio($show_medals_in_posts, "0").'>'.$lang['admin']['dont_show'].'&nbsp;&nbsp;</td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['show_admin_info'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="1" name="show_admin_info" '.check_radio($show_admin_info, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;</td>
        <td class="userdetails_data" colspan="3"><input type="radio" value="0" name="show_admin_info" '.check_radio($show_admin_info, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['show_admin_topics'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="1" name="show_admin_topics" '.check_radio($show_admin_topics, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;</td>
        <td class="userdetails_data" colspan="3"><input type="radio" value="0" name="show_admin_topics" '.check_radio($show_admin_topics, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['show_mod_at_home'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="1" name="show_moderators" '.check_radio($show_moderators, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;</td>
        <td class="userdetails_data" colspan="3"><input type="radio" value="0" name="show_moderators" '.check_radio($show_moderators, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['show_alexa_info'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="1" name="show_alexa_traffic" '.check_radio($show_alexa_traffic, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;</td>
        <td class="userdetails_data" colspan="3"><input type="radio" value="0" name="show_alexa_traffic" '.check_radio($show_alexa_traffic, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['show_another_forum'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="1" name="another_forum" '.check_radio($another_forum, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;</td>
        <td class="userdetails_data" colspan="3"><input type="radio" value="0" name="another_forum" '.check_radio($another_forum, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>	
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['mod_points'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="mod_points" size="10" value="'.$mod_points.'"></td>
	</tr>	
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['mod_online'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="online_mod_points" size="10" value="'.$online_mod_points.'"></td>
	</tr>	
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['forum_online'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="forum_online" size="10" value="'.$forum_online.'"></td>
	</tr>		
	<tr class="fixed">
		<td class="cat" colspan="5"><nobr>'.$lang['admin']['options'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['help_forum_icons'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="help_forum" size="10" value="'.$help_forum.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['blog_forum'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="blog_forum" size="10" value="'.$blog_forum.'"></td>
	</tr>	
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['num_change_username'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="change_name_max" size="10" value="'.$change_name_max.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['days_between_change_username'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="changename_dayslimit" size="10" value="'.$changename_dayslimit.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['max_page'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="page_number" size="10" value="'.$max_page.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['total_replies_to_lock_topic'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="total_post_close_topic" size="10" value="'.$total_post_close_topic.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['total_pm_for_member'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="total_pm_msg" size="10" value="'.$total_pm_message.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['max_search_member'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="max_search" size="10" value="'.$max_search.'"></td>
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['total_pm_for_mod'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="total_pm_msg_m" size="10" value="'.$total_pm_message_m.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['max_search_mod'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="max_search_m" size="10" value="'.$max_search_m.'"></td>
	</tr>
	<tr class="fixed">
		<td class="cat" colspan="5"><nobr>'.$lang['admin']['size_now'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['size_now_member_topic'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="topic_max_size" size="10" value="'.$topic_max_size.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($topic_max_size).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['size_now_member_reply'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="reply_max_size" size="10" value="'.$reply_max_size.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($reply_max_size).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['size_now_member_pm'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="pm_max_size" size="10" value="'.$pm_max_size.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($pm_max_size).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['size_now_member_sig'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="sig_max_size" size="10" value="'.$sig_max_size.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($sig_max_size).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['size_now_mod_topic'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="topic_max_size_m" size="10" value="'.$topic_max_size_m.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($topic_max_size).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['size_now_mod_reply'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="reply_max_size_m" size="10" value="'.$reply_max_size_m.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($reply_max_size).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['size_now_mod_pm'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="pm_max_size_m" size="10" value="'.$pm_max_size_m.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($pm_max_size).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['size_now_mod_sig'].'</nobr></td>
		<td class="middle" colspan="4"><input type="text" name="sig_max_size_m" size="10" value="'.$sig_max_size_m.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($sig_max_size).') '.$lang['other']['kb'].'</font></td>
	</tr>	
 	<tr class="fixed">
		<td align="middle" colspan="5"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($error == "") {

updata_mysql("SHOW_HKMA_SITEMAP", htmlspecialchars(DBi::$con->real_escape_string($_POST["show_hkma_sitemap"])));
updata_mysql("FORUM_ONLINE", htmlspecialchars(DBi::$con->real_escape_string($_POST["forum_online"])));
updata_mysql("MOD_POINTS", htmlspecialchars(DBi::$con->real_escape_string($_POST["mod_points"])));
updata_mysql("ONLINE_MOD_POINTS", htmlspecialchars(DBi::$con->real_escape_string($_POST["online_mod_points"])));
updata_mysql("ACTIVE_PORTAL", htmlspecialchars(DBi::$con->real_escape_string($_POST["active_portal"])));
updata_mysql("PAGE_NUMBER", htmlspecialchars(DBi::$con->real_escape_string($_POST["page_number"])));
updata_mysql("TOTAL_POST_CLOSE_TOPIC", htmlspecialchars(DBi::$con->real_escape_string($_POST["total_post_close_topic"])));
updata_mysql("TOTAL_PM_MSG", htmlspecialchars(DBi::$con->real_escape_string($_POST["total_pm_msg"])));
updata_mysql("TOPIC_MAX_SIZE", htmlspecialchars(DBi::$con->real_escape_string($_POST['topic_max_size'])));
updata_mysql("REPLY_MAX_SIZE", htmlspecialchars(DBi::$con->real_escape_string($_POST['reply_max_size'])));
updata_mysql("PM_MAX_SIZE", htmlspecialchars(DBi::$con->real_escape_string($_POST['pm_max_size'])));
updata_mysql("SIG_MAX_SIZE", htmlspecialchars(DBi::$con->real_escape_string($_POST['sig_max_size'])));
updata_mysql("TOTAL_PM_MSG_M", htmlspecialchars(DBi::$con->real_escape_string($_POST["total_pm_msg_m"])));
updata_mysql("TOPIC_MAX_SIZE_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['topic_max_size_m'])));
updata_mysql("REPLY_MAX_SIZE_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['reply_max_size_m'])));
updata_mysql("PM_MAX_SIZE_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['pm_max_size_m'])));
updata_mysql("SIG_MAX_SIZE_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['sig_max_size_m'])));
updata_mysql("SHOW_ADMIN_INFO", htmlspecialchars(DBi::$con->real_escape_string($_POST['show_admin_info'])));
updata_mysql("HELP_FORUM", htmlspecialchars(DBi::$con->real_escape_string($_POST['help_forum'])));
updata_mysql("BLOG_FORUM", htmlspecialchars(DBi::$con->real_escape_string($_POST['blog_forum'])));
updata_mysql("CHANGE_NAME_MAX", htmlspecialchars(DBi::$con->real_escape_string($_POST['change_name_max'])));
updata_mysql("CHANGENAME_DAYSLIMIT", htmlspecialchars(DBi::$con->real_escape_string($_POST['changename_dayslimit'])));
updata_mysql("SHOW_MODERATORS", htmlspecialchars(DBi::$con->real_escape_string($_POST['show_moderators'])));
updata_mysql("SHOW_ALEXA_TRAFFIC", htmlspecialchars(DBi::$con->real_escape_string($_POST['show_alexa_traffic'])));
updata_mysql("REGISTER_WAITTING", htmlspecialchars(DBi::$con->real_escape_string($_POST['register_waitting'])));
updata_mysql("SHOW_MEDALS_IN_POSTS", htmlspecialchars(DBi::$con->real_escape_string($_POST['show_medals_in_posts'])));
updata_mysql("SHOW_ADMIN_TOPICS", htmlspecialchars(DBi::$con->real_escape_string($_POST['show_admin_topics'])));
updata_mysql("MAX_SEARCH", htmlspecialchars(DBi::$con->real_escape_string($_POST['max_search'])));
updata_mysql("MAX_SEARCH_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['max_search_m'])));
updata_mysql("ANOTHER_FORUM", htmlspecialchars(DBi::$con->real_escape_string($_POST['another_forum'])));

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=option&method=other">
                           <a href="cp_home.php?mode=option&method=other">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}


if ($method == "editor") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="60%">
<form method="post" action="cp_home.php?mode=option&method=editor&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['editor_options'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_html'].'</nobr></td>
		<td width="60%" class="userdetails_data">
        <input class="radio" type="radio" value="true" name="ed_full_html" '.check_radio($editor_full_html, "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="ed_full_html" '.check_radio($editor_full_html, "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_width'].'</nobr></td>
		<td class="middle"><input type="text" name="ed_width" size="10" value="'.$editor_width.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_height'].'</nobr></td>
		<td class="middle"><input type="text" name="ed_height" size="10" value="'.$editor_height.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['editor_icons_options'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_1'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_0" '.check_radio($EditorIcon[0], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_0" '.check_radio($EditorIcon[0], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_2'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_1" '.check_radio($EditorIcon[1], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_1" '.check_radio($EditorIcon[1], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_3'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_2" '.check_radio($EditorIcon[2], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_2" '.check_radio($EditorIcon[2], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_4'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_3" '.check_radio($EditorIcon[3], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_3" '.check_radio($EditorIcon[3], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_5'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_4" '.check_radio($EditorIcon[4], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_4" '.check_radio($EditorIcon[4], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_6'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_5" '.check_radio($EditorIcon[5], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_5" '.check_radio($EditorIcon[5], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_7'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_6" '.check_radio($EditorIcon[6], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_6" '.check_radio($EditorIcon[6], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_8'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_7" '.check_radio($EditorIcon[7], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_7" '.check_radio($EditorIcon[7], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_9'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_8" '.check_radio($EditorIcon[8], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_8" '.check_radio($EditorIcon[8], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_10'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_9" '.check_radio($EditorIcon[9], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_9" '.check_radio($EditorIcon[9], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_11'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_10" '.check_radio($EditorIcon[10], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_10" '.check_radio($EditorIcon[10], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_12'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_11" '.check_radio($EditorIcon[11], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_11" '.check_radio($EditorIcon[11], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_13'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_12" '.check_radio($EditorIcon[12], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_12" '.check_radio($EditorIcon[12], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_14'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_13" '.check_radio($EditorIcon[13], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_13" '.check_radio($EditorIcon[13], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_15'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_14" '.check_radio($EditorIcon[14], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_14" '.check_radio($EditorIcon[14], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_16'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_15" '.check_radio($EditorIcon[15], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_15" '.check_radio($EditorIcon[15], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_17'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_16" '.check_radio($EditorIcon[16], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_16" '.check_radio($EditorIcon[16], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_18'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_17" '.check_radio($EditorIcon[17], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_17" '.check_radio($EditorIcon[17], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_19'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_18" '.check_radio($EditorIcon[18], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_18" '.check_radio($EditorIcon[18], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_20'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_19" '.check_radio($EditorIcon[19], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_19" '.check_radio($EditorIcon[19], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_21'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_20" '.check_radio($EditorIcon[20], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_20" '.check_radio($EditorIcon[20], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_22'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_21" '.check_radio($EditorIcon[21], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_21" '.check_radio($EditorIcon[21], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_23'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_22" '.check_radio($EditorIcon[22], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_22" '.check_radio($EditorIcon[22], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_24'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_23" '.check_radio($EditorIcon[23], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_23" '.check_radio($EditorIcon[23], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_25'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_24" '.check_radio($EditorIcon[24], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_24" '.check_radio($EditorIcon[24], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_26'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_25" '.check_radio($EditorIcon[25], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_25" '.check_radio($EditorIcon[25], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_27'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_26" '.check_radio($EditorIcon[26], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_26" '.check_radio($EditorIcon[26], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_28'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_27" '.check_radio($EditorIcon[27], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_27" '.check_radio($EditorIcon[27], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_29'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_28" '.check_radio($EditorIcon[28], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_28" '.check_radio($EditorIcon[28], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_30'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_29" '.check_radio($EditorIcon[29], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_29" '.check_radio($EditorIcon[29], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_31'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_30" '.check_radio($EditorIcon[30], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_30" '.check_radio($EditorIcon[30], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_32'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_31" '.check_radio($EditorIcon[31], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_31" '.check_radio($EditorIcon[31], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_33'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_32" '.check_radio($EditorIcon[32], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_32" '.check_radio($EditorIcon[32], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_34'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_33" '.check_radio($EditorIcon[33], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_33" '.check_radio($EditorIcon[33], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_35'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_34" '.check_radio($EditorIcon[34], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_34" '.check_radio($EditorIcon[34], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_36'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_35" '.check_radio($EditorIcon[35], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_35" '.check_radio($EditorIcon[35], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_37'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_36" '.check_radio($EditorIcon[36], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_36" '.check_radio($EditorIcon[36], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_38'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_37" '.check_radio($EditorIcon[37], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_37" '.check_radio($EditorIcon[37], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_39'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_38" '.check_radio($EditorIcon[38], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_38" '.check_radio($EditorIcon[38], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_40'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_39" '.check_radio($EditorIcon[39], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_39" '.check_radio($EditorIcon[39], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['editor_icon_42'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_41" '.check_radio($EditorIcon[41], "true").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_41" '.check_radio($EditorIcon[41], "false").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("EDITOR_FULL_HTML", $_POST['ed_full_html']);
updata_mysql("EDITOR_WIDTH", htmlspecialchars(DBi::$con->real_escape_string($_POST['ed_width'])));
updata_mysql("EDITOR_HEIGHT", htmlspecialchars(DBi::$con->real_escape_string($_POST['ed_height'])));

updata_mysql("EDITOR_ICON_SAVE", $_POST['icon_0']);
updata_mysql("EDITOR_ICON_PRINT", $_POST['icon_1']);
updata_mysql("EDITOR_ICON_ZOOM", $_POST['icon_2']);
updata_mysql("EDITOR_ICON_STYLE", $_POST['icon_3']);
updata_mysql("EDITOR_ICON_PARAGRAPH", $_POST['icon_4']);
updata_mysql("EDITOR_ICON_FONT_NAME", $_POST['icon_5']);
updata_mysql("EDITOR_ICON_SIZE", $_POST['icon_6']);
updata_mysql("EDITOR_ICON_TEXT", $_POST['icon_7']);
updata_mysql("EDITOR_ICON_SELECT_ALL", $_POST['icon_8']);
updata_mysql("EDITOR_ICON_CUT", $_POST['icon_9']);
updata_mysql("EDITOR_ICON_COPY", $_POST['icon_10']);
updata_mysql("EDITOR_ICON_PASTE", $_POST['icon_11']);
updata_mysql("EDITOR_ICON_UNDO", $_POST['icon_12']);
updata_mysql("EDITOR_ICON_REDO", $_POST['icon_13']);
updata_mysql("EDITOR_ICON_BOLD", $_POST['icon_14']);
updata_mysql("EDITOR_ICON_ITALIC", $_POST['icon_15']);
updata_mysql("EDITOR_ICON_UNDER_LINE", $_POST['icon_16']);
updata_mysql("EDITOR_ICON_STRIKE", $_POST['icon_17']);
updata_mysql("EDITOR_ICON_SUPER_SCRIPT", $_POST['icon_18']);
updata_mysql("EDITOR_ICON_SUB_SCRIPT", $_POST['icon_19']);
updata_mysql("EDITOR_ICON_SYMBOL", $_POST['icon_20']);
updata_mysql("EDITOR_ICON_LEFT", $_POST['icon_21']);
updata_mysql("EDITOR_ICON_CENTER", $_POST['icon_22']);
updata_mysql("EDITOR_ICON_RIGHT", $_POST['icon_23']);
updata_mysql("EDITOR_ICON_FULL", $_POST['icon_24']);
updata_mysql("EDITOR_ICON_NUBERING", $_POST['icon_25']);
updata_mysql("EDITOR_ICON_BULLETS", $_POST['icon_26']);
updata_mysql("EDITOR_ICON_INDENT", $_POST['icon_27']);
updata_mysql("EDITOR_ICON_OUTDENT", $_POST['icon_28']);
updata_mysql("EDITOR_ICON_IMAGE", $_POST['icon_29']);
updata_mysql("EDITOR_ICON_COLOR", $_POST['icon_30']);
updata_mysql("EDITOR_ICON_BGCOLOR", $_POST['icon_31']);
updata_mysql("EDITOR_ICON_EX_LINK", $_POST['icon_32']);
updata_mysql("EDITOR_ICON_IN_LINK", $_POST['icon_33']);
updata_mysql("EDITOR_ICON_ASSET", $_POST['icon_34']);
updata_mysql("EDITOR_ICON_TABLE", $_POST['icon_35']);
updata_mysql("EDITOR_ICON_SHOW_BORDER", $_POST['icon_36']);
updata_mysql("EDITOR_ICON_ABSOLUTE", $_POST['icon_37']);
updata_mysql("EDITOR_ICON_CLEAN", $_POST['icon_38']);
updata_mysql("EDITOR_ICON_LINE", $_POST['icon_39']);
updata_mysql("EDITOR_ICON_PROPERTIES", $_POST['icon_40']);
updata_mysql("EDITOR_ICON_WORD", $_POST['icon_41']);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=option&method=editor">
                           <a href="cp_home.php?mode=option&method=other">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}
 
 
 if ($method == "files") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="3" width="80%">
<form method="post" action="cp_home.php?mode=option&method=files&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['others']['files_options'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['others']['files_size'].'</nobr></td>
		<td class="middle"><input type="text" name="files_max_size" size="10" value="'.$Files_Max_Size.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($Files_Max_Size).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['others']['files_max'].'</nobr></td>
		<td class="middle"><input type="text" name="files_max_allowed" size="10" value="'.$Files_Max_Allowed.'"><font color="black">&nbsp;'.$lang['other']['byte'].'&nbsp;&nbsp;/&nbsp;&nbsp;'.$lang['other']['to_from'].' ('.to_kb($Files_Max_Allowed).') '.$lang['other']['kb'].'</font></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("FILES_MAX_SIZE", $_POST['files_max_size']);
updata_mysql("FILES_MAX_ALLOWED", $_POST['files_max_allowed']);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=option&method=files">
                           <a href="cp_home.php?mode=option&method=files">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}



//--------------------------------------------------------------------------------------------------
if ($method == "site") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="3" width="80%">
<form method="post" action="cp_home.php?mode=option&method=site&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['site_options'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['site_time'].'</nobr></td>
		<td class="middle">
			<select class="insidetitle" name="site_timezone">
			<option value="-12" '.check_select($site_timezone, "-12").'>'.$lang['admin']['time_gmt-12'].'</option>
			<option value="-11" '.check_select($site_timezone, "-11").'>'.$lang['admin']['time_gmt-11'].'</option>
			<option value="-10" '.check_select($site_timezone, "-10").'>'.$lang['admin']['time_gmt-10'].'</option>
			<option value="-9" '.check_select($site_timezone, "-9").'>'.$lang['admin']['time_gmt-9'].'</option>
			<option value="-8" '.check_select($site_timezone, "-8").'>'.$lang['admin']['time_gmt-8'].'</option>
			<option value="-7" '.check_select($site_timezone, "-7").'>'.$lang['admin']['time_gmt-7'].'</option>
			<option value="-6" '.check_select($site_timezone, "-6").'>'.$lang['admin']['time_gmt-6'].'</option>
			<option value="-5" '.check_select($site_timezone, "-5").'>'.$lang['admin']['time_gmt-5'].'</option>
			<option value="-4" '.check_select($site_timezone, "-4").'>'.$lang['admin']['time_gmt-4'].'</option>
			<option value="-3" '.check_select($site_timezone, "-3").'>'.$lang['admin']['time_gmt-3'].'</option>
			<option value="-2" '.check_select($site_timezone, "-2").'>'.$lang['admin']['time_gmt-2'].'</option>
			<option value="-1" '.check_select($site_timezone, "-1").'>'.$lang['admin']['time_gmt-1'].'</option>
			<option value="0" '.check_select($site_timezone, "0").'>'.$lang['admin']['time_gmt-0'].'</option>
			<option value="1" '.check_select($site_timezone, "1").'>'.$lang['admin']['time_gmt+1'].'</option>
			<option value="2" '.check_select($site_timezone, "2").'>'.$lang['admin']['time_gmt+2'].'</option>
			<option value="3" '.check_select($site_timezone, "3").'>'.$lang['admin']['time_gmt+3'].'</option>
			<option value="4" '.check_select($site_timezone, "4").'>'.$lang['admin']['time_gmt+4'].'</option>
			<option value="5" '.check_select($site_timezone, "5").'>'.$lang['admin']['time_gmt+5'].'</option>
			<option value="6" '.check_select($site_timezone, "6").'>'.$lang['admin']['time_gmt+6'].'</option>
			<option value="7" '.check_select($site_timezone, "7").'>'.$lang['admin']['time_gmt+7'].'</option>
			<option value="8" '.check_select($site_timezone, "8").'>'.$lang['admin']['time_gmt+8'].'</option>
			<option value="9" '.check_select($site_timezone, "9").'>'.$lang['admin']['time_gmt+9'].'</option>
			<option value="10" '.check_select($site_timezone, "10").'>'.$lang['admin']['time_gmt+10'].'</option>
			<option value="11" '.check_select($site_timezone, "11").'>'.$lang['admin']['time_gmt+11'].'</option>
			<option value="12" '.check_select($site_timezone, "12").'>'.$lang['admin']['time_gmt+12'].'</option>
			</select>
		</td>
	</tr>
	
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['+_-_time'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['add_cat_forum']['active'].'</nobr></td>
		<td class="middle">
			<select class="insidetitle" name="time_active">
			<option value="1" '.check_select($time_active, "1").'>'.$lang['add_cat_forum']['yes'].'</option>
			<option value="0" '.check_select($time_active, "0").'>'.$lang['add_cat_forum']['no'].'</option>
			</select>
		</td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['time_status'].'</nobr></td>
		<td class="middle">
			<select class="insidetitle" name="time_status">
			<option value="1" '.check_select($time_status, "1").'>'.$lang['admin']['+'].'</option>
			<option value="2" '.check_select($time_status, "2").'>'.$lang['admin']['-'].'</option>
			</select>
		</td>
	</tr>	
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['num_seconds'].'</nobr></td>
		<td class="middle">
			<input value="'.$time_second.'" name="time_second">
		</td>
	</tr>	
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
	<tr class="fixed">
	<td align="middle" colspan="2"><font color="black">'.$lang['admin']['useing_time'].'</font></td>
	</tr>
</form>
</table>
</center>';
 }
 if ($type == "insert_data") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($error == "") {

updata_mysql("SITE_TIMEZONE", $_POST['site_timezone']);
updata_mysql("TIME_ACTIVE", $_POST['time_active']);
updata_mysql("TIME_STATUS", $_POST['time_status']);
updata_mysql("TIME_SECOND", DBi::$con->real_escape_string(trim($_POST['time_second'])));

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=site">
                           <a href="cp_home.php?mode=option&method=site">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}
//-------------------------------------------------------------------------------------------------- 

//--------------------------------------------------------------------------------------------------
if ($method == "ip") {

 if ($type == "") {

echo'
<script type="text/javascript">
function deleteItem(id){
if(confirm("'.$lang['admin']['confirm_delete_ip'] .'")){
window.location = "cp_home.php?mode=option&method=ip&type=del&id="+id;
}else{
return;
}
}
function get_ip(){
var ipsearch = document.getElementById("ipsearch").value;
window.location="cp_home.php?mode=option&method=ip&ip="+ipsearch;
}
</script>
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="1" width="80%">
<form name="fip" method="post" action="cp_home.php?mode=option&method=ip&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['ip_options'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['new_ip'].'</nobr></td>
		<td class="middle">
			<input type="text" name="ip">&nbsp;
			<select class="insidetitle" name="date_unban">
			<option value="always">'.$lang['admin']['block_always'].'</option>
			<option value="1">'.$lang['admin']['block_1'].'</option>
			<option value="2">'.$lang['admin']['block_2'].'</option>
			<option value="3">'.$lang['admin']['block_3'].'</option>
			<option value="4">'.$lang['admin']['block_4'].'</option>
			<option value="5">'.$lang['admin']['block_5'].'</option>
			<option value="7">'.$lang['admin']['block_7'].'</option>
			<option value="14">'.$lang['admin']['block_14'].'</option>
			<option value="30">'.$lang['admin']['block_30'].'</option>
			<option value="60">'.$lang['admin']['block_60'].'</option>
			<option value="360">'.$lang['admin']['block_360'].'</option>
			<option value="720">'.$lang['admin']['block_720'].'</option>
			</select>&nbsp;
			<textarea name="why" style="HEIGHT: 60px;WIDTH: 200px;FONT-WEIGHT: bold;FONT-SIZE: 15px;BACKGROUND-COLOR: #91BBC9;COLOR: white;FONT-FAMILY: arial"></textarea>
		</td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></form></td>
	</tr>
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['search_ip'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list" colspan="2"><nobr>'.$lang['admin']['insert_ip_to_search'].'&nbsp;&nbsp;<input type="text" name="ipsearch" id="ipsearch">&nbsp;&nbsp;<input type="button" value="'.$lang['profile']['insert_info'].'" onclick="get_ip()"></nobr></td>
	</tr>';

                   if($_GET['ip']){
                      $ip = htmlspecialchars(DBi::$con->real_escape_string($_GET['ip']));
                      $sql = DBi::$con->query("select * from ".prefix."MEMBERS WHERE M_IP = '$ip' OR M_LAST_IP = '$ip' ");
                               if(mysqli_num_rows($sql) == 0){
                                 echo '<tr class="fixed"><td align="center" class="list" colspan="2">'.$lang['admin']['no_ip'].'</td></tr>';
                               }else{
                               while($r = mysqli_fetch_array($sql)){
                                 echo '<tr class="fixed"><td align="center" class="list" colspan="2">'.link_profile($r['M_NAME'], $r['MEMBER_ID']).'</td></tr>';
                               }                  }
                    }
	echo '<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['blocked_ips'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list" colspan="2">
<table  width="100%">
<tr>
		<td class="optionheader_selected">'.$lang['admin']['ip'].'</td>
		<td class="optionheader_selected">'.$lang['admin']['date_ip'].'</td>
		<td class="optionheader_selected">'.$lang['admin']['ip_from'].'</td>
		<td class="optionheader_selected">'.$lang['admin']['ip_why'].'</td>
		<td class="optionheader_selected">'.$lang['admin']['date_ip_delete'].'</td>
		<td class="optionheader_selected">&nbsp;</td>
</tr>';
$Sql = DBi::$con->query("SELECT * FROM ".prefix."IP_BAN ORDER BY ID ASC ");
$Num = mysqli_num_rows($Sql);
if($Num == 0){
echo '<tr class="fixed">
		<td class="list_center" colspan="6">'.$lang['admin']['no_ip'].'</td>
</tr>';
}
if($Num != 0){
while($r = mysqli_fetch_array($Sql)){

if($r['DATE_UNBAN'] == '0'){
$un_ban = "<font color=\"red\">".$lang['admin']['block_always']."</font>";
}else{
$un_ban = normal_date($r['DATE_UNBAN']);
}

echo '<tr class="fixed">
		<td class="list_center">'.$r['IP'].'</td>
		<td class="list_center">'.normal_date($r['DATE']).'</td>
		<td class="list_center">'.member_name($r['HWO']).'</td>
		<td class="list_center">'.$r['WHY'].'</td>
		<td class="list_center">'.$un_ban.'</td>
		<td class="list_center"><a href="javascript:deleteItem('.$r['ID'].')">'.icons($icon_trash,$lang['admin']['delete_block_ip_member']).'</a></td>
</tr>';
}
}
echo '</table>
</td></tr></table>
</center>';
 }

 if ($type == "insert_data") {
$ip = htmlspecialchars(DBi::$con->real_escape_string($_POST['ip']));
$why = htmlspecialchars(DBi::$con->real_escape_string($_POST['why']));
$date_unban = htmlspecialchars(DBi::$con->real_escape_string($_POST['date_unban']));
if($date_unban == 'always'){
$date_unban = 0;
}else{
$date_unban = time() + (60 * 60 * 24 * $date_unban);
}

$date = time();

if(!$ip){
$error = $lang['admin']['no_enter_ip'];
}

if(!$why){
$error = $lang['admin']['no_enter_ip_why'];
}

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

    if ($error == "") {
DBi::$con->query("INSERT INTO ".prefix."IP_BAN SET IP = '$ip',DATE = '$date',WHY = '$why',DATE_UNBAN = '$date_unban',HWO = '$CPMemberID' ") or die(DBi::$con->error);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['admin']['done_block_ip'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=ip">
                           <a href="cp_home.php?mode=option&method=ip">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }

if($type == "del"){
DBi::$con->query("DELETE FROM ".prefix."IP_BAN WHERE ID = '$id' ");

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['admin']['done_delete_ip'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=ip">
                           <a href="cp_home.php?mode=option&method=ip">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';

}}
//--------------------------------------------------------------------------------------------------

  //------------------------------------------------------------------------------------------------
if ($method == "list_m") {

 if ($type == "") {

echo '	<script language="JavaScript" type="text/javascript">
		function submitForm() {
			if (list_option.allowed_members_in_list.value.lenght == 0) {
				confirm("'.$lang['admin']['enter_member_number'].'");
			return;
			}
			if (list_option.allowed_members_in_list.value > 20) {
				confirm("'.$lang['admin']['num_more_20'].'");
			return;
			}
			if (list_option.allowed_members_in_forum_list.value.lenght == 0) {
				confirm("'.$lang['admin']['enter_members'].'");
			return;
			}
			if (list_option.allowed_members_in_forum_list.value > 60) {
				confirm("'.$lang['admin']['num_more_60'].'");
			return;
			}
		list_option.submit();
		}
	</script>
	<center>
	<table class="grid" border="0" cellspacing="1" cellpadding="3" width="80%">
	<form name="list_option" method="post" action="cp_home.php?mode=option&method=list_m&type=insert_data">
		<tr class="fixed">
			<td class="cat" colspan="2"><nobr>'.$lang['admin']['list_options'].'</nobr></td>
		</tr>
	 	<tr class="fixed">
			<td class="list" width="30%"><nobr>'.$lang['admin']['select_num_list'].'</nobr></td>
			<td class="list">
				<select class="insidetitle" name="member_allowed_lists">';

                                                                            for($i=3;$i<16;$i++){
					echo '<option value="'.$i.'" '.check_select($max_list_cat_members,$i).'>'.$i.'</option>';
                                                                            }
				echo '</select>
			</td>
		</tr>
	 	<tr class="fixed">
			<td class="list"><nobr>'.$lang['admin']['num_members_big'].'</nobr></td>
			<td class="list"><input class="small" type="text" size="1" name="allowed_members_in_list" value="'.$max_list_m_members.'"></td>
		</tr>
		<tr class="fixed">
			<td class="cat" colspan="2"><nobr>'.$lang['admin']['list_options_m'].'</nobr></td>
		</tr>
	 	<tr class="fixed">
			<td class="list" width="30%"><nobr>'.$lang['admin']['select_num_list_m'].'</nobr></td>
			<td class="list">
				<select class="insidetitle" name="forum_allowed_lists">';

                                                                            for($i=3;$i<16;$i++){
					echo '<option value="'.$i.'" '.check_select($max_list_cat_moderators,$i).'>'.$i.'</option>';
                                                                            }

				echo '</select>
			</td>
		</tr>
	 	<tr class="fixed">
			<td class="list"><nobr>'.$lang['admin']['num_members_big'].'</nobr></td>
			<td class="list"><input class="small" type="text" size="1" name="allowed_members_in_forum_list" value="'.$max_list_m_moderators.'"></td>
		</tr>
	 	<tr class="fixed">
			<td align="middle" colspan="3"><input type="button" value="'.$lang['profile']['insert_info'].'" onclick="submitForm();">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
		</tr>
	</form>
	</table>
	</center>';
}
 if ($type == "insert_data") {

updata_mysql("MAX_LIST_CAT_MEMBERS", $_POST['member_allowed_lists']);
updata_mysql("MAX_LIST_M_MEMBERS", htmlspecialchars(DBi::$con->real_escape_string($_POST['allowed_members_in_list'])));
updata_mysql("MAX_LIST_CAT_MODERATORS", $_POST['forum_allowed_lists']);
updata_mysql("MAX_LIST_M_MODERATORS", htmlspecialchars(DBi::$con->real_escape_string($_POST['allowed_members_in_forum_list'])));

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=list_m">
                           <a href="cp_home.php?mode=option&method=list_m">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}}
  //------------------------------------------------------------------------------------------------


}
else {
    go_to("index.php");
}
?>