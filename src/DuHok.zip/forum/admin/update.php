<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

ini_set('max_execution_time', 300); //300 seconds = 5 minutes

@require_once("./session.php");
@require_once("./language/".$choose_language.".php");
$changes = file_get_contents("http://dahuk.info/changes.html");
if($CPMlevel == 4) {
echo'
<html dir="rtl">
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="DUHOK FORUM 2.1: Copyright (C) 2015-2016 Duhok Team." name="copyright">
<link href="cp_styles/cp_style_green.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="./javascript/jquery.min.js"></script>
</head>
<body background="cp_styles/bg.jpg" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
<br>
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['auto_update']['update_site_auto'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td align="middle">
        <br>
        <font color="black">
        ---------------------------------------------------------------------------------
		 <br><br>';
		 if($type == "") {
			echo'
			<font color="black" size="4">'.$lang['auto_update']['desc'].'<br><br></font><font color="red" size="4">'.$lang['auto_update']['list_of_changes'].'<br><br>'.$changes.'</font><font color="black" size="4"><br><br>'.$lang['auto_update']['click_here_to_update'].'</font>';
			
		 }
		 if($type == "update") {
$version = file_get_contents("http://dahuk.info/version.js");
	 
updata_mysql("FORUM_STATUS", "1");
		 // get main dir
			$dir = $_SERVER['PHP_SELF'];
            $dir = 	explode('/',$dir);
            // get dir
			$To = $_SERVER['DOCUMENT_ROOT']."/".$dir[1]."/";
			$To = str_ireplace("cp_home.php/", '', $To);

		$duhok_last_time_updates = 'http://dahuk.info/df_new_files.txt';
		$last_time_updates = @file_get_contents($duhok_last_time_updates);

         if(!$last_time_updates)
		 {
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $duhok_last_time_updates);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$last_time_updates = curl_exec($ch);
		 }

		$arr = explode('-',$last_time_updates);
		$url     = trim($arr[2]);

        $file_get = fopen($url, 'r');

        file_put_contents($To."Tmpfile.zip", $file_get);

		$zip = new ZipArchive;
		$file = $To.'Tmpfile.zip';
		//$path = pathinfo(realpath($file), PATHINFO_DIRNAME);
		if ($zip->open($file) === TRUE) {
		    $zip->extractTo($To);
		    $zip->close();
			unlink($To."Tmpfile.zip");
			echo'<font color="green" size="5">'.$lang['auto_update']['click_here_to_update_db'].'</font>';
		} else {
			echo'<font color="red" size="5">'.$lang['auto_update']['error_auto_update'].'</font>';
		}
		 }
		 if($type == "db") {
		require_once("./update.php");
		unlink("./update.php");
		$version = file_get_contents("http://dahuk.info/version.js");
		updata_mysql("DUHOK_FORUM_VERSION", $version);
		updata_mysql("FORUM_STATUS", "0");
			echo'<font color="green" size="5">'.$lang['auto_update']['done_auto_update'].'</font>';
		 }
		 
echo'		
		<br><br>
		---------------------------------------------------------------------------------
		<br><br>
</font>
        </td>
	</tr>
</table>
</center>
</body>
</html>';
} else {
go_to("index.php");	
}
?>