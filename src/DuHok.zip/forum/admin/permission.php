<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");

if ($CPMlevel == 4) {

if ($method == "mon") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=permission&method=mon&type=insert">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['mon_permission'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['can_show_pm'].'</td>
		<td class="userdetails_data"><input type="radio" value="1" name="CAN_SHOW_PM" '.check_radio($CAN_SHOW_PM, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="0" name="CAN_SHOW_PM" '.check_radio($CAN_SHOW_PM, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['can_close_member'].'</td>
		<td class="userdetails_data"><input type="radio" value="1" name="CAN_CLOSE_M" '.check_radio($CAN_CLOSE_M, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="0" name="CAN_CLOSE_M" '.check_radio($CAN_CLOSE_M, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['can_open_member'].'</td>
		<td class="userdetails_data"><input type="radio" value="1" name="CAN_OPEN_M" '.check_radio($CAN_OPEN_M, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="0" name="CAN_OPEN_M" '.check_radio($CAN_OPEN_M, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['can_holded_member'].'</td>
		<td class="userdetails_data"><input type="radio" value="1" name="CAN_HOLDED_M" '.check_radio($CAN_HOLDED_M, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="0" name="CAN_HOLDED_M" '.check_radio($CAN_HOLDED_M, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>	
	<tr class="fixed">
		<td class="list">'.$lang['others']['control_members'].'</td>
		<td class="userdetails_data"><input type="radio" value="1" name="CAN_CHANGE_M" '.check_radio($CAN_CHANGE_M, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="0" name="CAN_CHANGE_M" '.check_radio($CAN_CHANGE_M, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>		
	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
';
echo'
</form>
</table>
</center>';
 }

 if ($type == "insert") {

updata_mysql("CAN_SHOW_PM", htmlspecialchars(DBi::$con->real_escape_string($_POST['CAN_SHOW_PM'])));
updata_mysql("CAN_CLOSE_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['CAN_CLOSE_M'])));
updata_mysql("CAN_OPEN_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['CAN_OPEN_M'])));
updata_mysql("CAN_HOLDED_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['CAN_HOLDED_M'])));
updata_mysql("CAN_CHANGE_M", htmlspecialchars(DBi::$con->real_escape_string($_POST['CAN_CHANGE_M'])));
    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=permission&method=mon">
                           <a href="cp_home.php?mode=permission&method=mon">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
}
if ($method == "mod") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=permission&method=mod&type=insert">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['mod_permission'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['can_add_titles'].'</nobr></td>
		<td class="userdetails_data">
        <input type="radio" value="1" name="mod_add_titles" '.check_radio($mod_add_titles, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" value="0" name="mod_add_titles" '.check_radio($mod_add_titles, "0").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['can_add_medals'].'</nobr></td>
		<td class="userdetails_data">
        <input type="radio" value="1" name="mod_add_medals" '.check_radio($mod_add_medals, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" value="0" name="mod_add_medals" '.check_radio($mod_add_medals, "0").'>'.$lang['add_cat_forum']['no'].'
        </td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert") {

$mod_add_titles = htmlspecialchars(DBi::$con->real_escape_string($_POST["mod_add_titles"]));
$mod_add_medals = htmlspecialchars(DBi::$con->real_escape_string($_POST["mod_add_medals"]));

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("MOD_ADD_TITLES", $mod_add_titles);
updata_mysql("MOD_ADD_MEDALS", $mod_add_medals);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=permission&method=mod">
                           <a href="cp_home.php?mode=permission&method=mod">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
}
 if ($method == "visitor") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=permission&method=visitor&type=insert">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['visitor_permission'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['show_forum'].'</td>
		<td class="userdetails_data"><input type="radio" value="0" name="CAN_SHOW_FORUM" '.check_radio($CAN_SHOW_FORUM, "0").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="1" name="CAN_SHOW_FORUM" '.check_radio($CAN_SHOW_FORUM, "1").'>'.$lang['add_cat_forum']['no'].'</td>
	</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['show_topics'].'</td>
		<td class="userdetails_data"><input type="radio" value="0" name="CAN_SHOW_TOPIC" '.check_radio($CAN_SHOW_TOPIC, "0").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="1" name="CAN_SHOW_TOPIC" '.check_radio($CAN_SHOW_TOPIC, "1").'>'.$lang['add_cat_forum']['no'].'
&nbsp;&nbsp;
        <input type="radio" value="2" name="CAN_SHOW_TOPIC" '.check_radio($CAN_SHOW_TOPIC, "2").'>'.$lang['admin']['part_of_topic'].'
</td>
	</tr>
	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
';
echo'
</form>
</table>
</center>';
 }

 if ($type == "insert") {


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("CAN_SHOW_FORUM", htmlspecialchars(DBi::$con->real_escape_string($_POST['CAN_SHOW_FORUM'])));
updata_mysql("CAN_SHOW_TOPIC", htmlspecialchars(DBi::$con->real_escape_string($_POST['CAN_SHOW_TOPIC'])));

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=permission&method=visitor">
                           <a href="cp_home.php?mode=permission&method=visitor">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
}
 if ($method == "new") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=permission&method=new&type=insert">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['new_member_permission'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['posts_to_show_topics'].'</nobr></td>
		<td class="middle"><input type="text" name="new_member_show_topic" size="10" value="'.$new_member_show_topic.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['posts_to_delete_moderation'].'</nobr></td>
		<td class="middle"><input type="text" name="new_member_min_posts" size="10" value="'.$new_member_min_posts.'"></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['posts_to_change_name'].'</nobr></td>
		<td class="middle"><input type="text" name="new_member_change_name" size="10" value="'.$new_member_change_name.'">
	</tr>
<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['posts_to_delete_messages'].'</nobr></td>
		<td class="middle"><input type="text" name="new_member_min_posts_pm" size="10" value="'.$new_member_min_posts_pm.'"></td>
		</tr>
<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['posts_to_delete_search'].'</nobr></td>
		<td class="middle"><input type="text" name="new_member_min_search" size="10" value="'.$new_member_min_search.'"></td>
	</tr>
	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
';
echo'
</form>
</table>
</center>';
 }

 if ($type == "insert") {

updata_mysql("NEW_MEMBER_MIN_SEARCH", htmlspecialchars(DBi::$con->real_escape_string($_POST['new_member_min_search'])));
updata_mysql("NEW_MEMBER_SHOW_TOPIC", htmlspecialchars(DBi::$con->real_escape_string($_POST['new_member_show_topic'])));
updata_mysql("NEW_MEMBER_CHANGE_NAME", htmlspecialchars(DBi::$con->real_escape_string($_POST['new_member_change_name'])));
updata_mysql("NEW_MEMBER_MIN_POSTS_PM", htmlspecialchars(DBi::$con->real_escape_string($_POST['new_member_min_posts_pm'])));
updata_mysql("NEW_MEMBER_MIN_POSTS", htmlspecialchars(DBi::$con->real_escape_string($_POST['new_member_min_posts'])));
    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($error == "") {

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=permission&method=new">
                           <a href="cp_home.php?mode=permission&method=new">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
}
}
else {
    go_to("index.php");
}
?>