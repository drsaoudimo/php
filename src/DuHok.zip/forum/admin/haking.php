<?php
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");

if ($CPMlevel == 4) {
	
 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="1" width="80%">
<form name="fip" method="post">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['haking_members'].'</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list" colspan="2">
<table  width="100%">
<tr>
		<td class="optionheader_selected">'.$lang['admin']['ip'].'</td>
		<td class="optionheader_selected">'.$lang['admin']['the_hacked'].'</td>
		<td class="optionheader_selected">'.$lang['admin']['the_hacking'].'</td>
		<td class="optionheader_selected">'.$lang['admin']['the_status'].'</td>
		<td class="optionheader_selected">&nbsp;</td>
</tr>';
$Sql = DBi::$con->query("SELECT * FROM ".prefix."HAKING ORDER BY ID DESC ");
$Num = mysqli_num_rows($Sql);
if($Num == 0){
echo '<tr class="fixed">
		<td class="list_center" colspan="6">'.$lang['admin']['no_ip'].'</td>
</tr>';
}
if($Num != 0){
while($r = mysqli_fetch_array($Sql)){
	
if($r['TYPE'] == 1) {
$txt = $lang['admin']['hack_member'];	
}
if($r['TYPE'] == 2) {
$txt = $lang['admin']['hack_moderator'];	
}
if($r['TYPE'] == 3) {
$txt = $lang['admin']['hack_monitor'];	
}
if($r['TYPE'] == 4) {
$txt = $lang['admin']['hack_admin'];	
}	
if($r['TYPE'] == 5) {
$txt = $lang['temy_other']['hack_the_admin'];	
}	

echo '<tr class="fixed">
		<td class="list_center">'.$r['IP'].'</td>
		<td class="list_center">'.link_profile(member_name($r['MEMBER']),$r['MEMBER']).'</td>';
$the_ip = $r['IP'];		
$sql = DBi::$con->query("SELECT * FROM ".prefix."IP WHERE IP = '$the_ip' AND M_ID != '0'");
if(mysqli_num_rows($sql) > 0) {
$rr = mysqli_fetch_array($sql);	
$member_id = $rr['M_ID'];
echo'
		<td class="list_center">'.link_profile(member_name($member_id), $member_id).'</td>
';
}
echo'		
		<td class="list_center">'.$txt.'</td>
		<td class="list_center"><a href="cp_home.php?mode=haking&type=del&id='.$r['IP'].'">'.icons($icon_ip,$lang['admin']['confirm_do_this']).'</a></td>
</tr>';
}
}
echo '</table>
</td></tr></table>
</center>';
 }


if($type == "del"){
if($id != "") {	
$date = time();
$why = $lang['admin']['hacker'];
$date_unban = "always";
$sql = DBi::$con->query("SELECT * FROM ".prefix."IP WHERE IP = '$id' AND M_ID != '0'");
if(mysqli_num_rows($sql) > 0) {
$rr = mysqli_fetch_array($sql);	
$member_id = $rr['M_ID'];
}
if(members("LEVEL", $member_id) != 4 && $member_id != 1) {
DBi::$con->query("INSERT INTO ".prefix."IP_BAN SET IP = '$id',DATE = '$date',WHY = '$why',DATE_UNBAN = '$date_unban',HWO = '$CPMemberID' ") or die(DBi::$con->error);
		$query = "UPDATE " . $Prefix . "MEMBERS SET ";
        $query .= " M_STATUS = ('0') ";
        $query .= "WHERE MEMBER_ID = '$member_id' ";
@		DBi::$con->query($query) or die (DBi::$con->error);
}

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['admin']['done_block_ip'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=ip">
                           <a href="cp_home.php?mode=option&method=ip">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';

}
}
} else {
go_to("index.php");	
}
?>