<?

error_reporting(0);
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");

if ($CPMlevel == 4) {

 if ($type == "") {

echo'
<script type="text/javascript" src="'.$admin_folder.'/colors.js"></script>

<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=special&type=insert">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['edit_ihdaa'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['active_ihdaa'].'</td>
		<td class="userdetails_data"><input type="radio" value="1" name="WHAT_ACTIVE" '.check_radio($WHAT_ACTIVE, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="0" name="WHAT_ACTIVE" '.check_radio($WHAT_ACTIVE, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ihdaa_title'].'</nobr></td>
		<td class="middle"><input type="text"  name="WHAT_TITLE" size="50" value="'.$WHAT_TITLE.'"></td>
	</tr>
		</tr>
		<tr class="fixed">
		<td class="list">'.$lang['admin']['ihdaa_font_size'].'</td>
				<td class="middle"><input type="text"  name="WHAT_ADMIN_SHOW" size="50" value="'.$WHAT_ADMIN_SHOW.'"></td>

		</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['num_posts_to_add_ihdaa'].'</td>
		<td class="middle"><input type="text"  name="WHAT_LIMIT" size="50" value="'.$WHAT_LIMIT.'"></td>
	</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['break_between_ihdaa'].'</td>
		<td class="middle"><input type="text"  name="WHAT_FASEL" size="50" value="'.$WHAT_FASEL.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['color_break'].'</nobr></td>
<td class="middle" align="center">
				<script language="javascript" type="text/javascript">
					document.write(color_palette("'.$WHAT_COLOR.'",0));
				</script>
<input type="hidden" name="g0"  id="g0" value="'.$WHAT_COLOR.'">
	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
';
echo'
</form>
</table>
</center>';
 }

 if ($type == "insert") {

updata_mysql("WHAT_ACTIVE", $_POST['WHAT_ACTIVE']);
updata_mysql("WHAT_TITLE", htmlspecialchars(DBi::$con->real_escape_string($_POST['WHAT_TITLE'])));
updata_mysql("WHAT_ADMIN_SHOW", htmlspecialchars(DBi::$con->real_escape_string($_POST['WHAT_ADMIN_SHOW'])));
updata_mysql("WHAT_LIMIT", htmlspecialchars(DBi::$con->real_escape_string($_POST['WHAT_LIMIT'])));
updata_mysql("WHAT_FASEL", htmlspecialchars(DBi::$con->real_escape_string($_POST['WHAT_FASEL'])));
updata_mysql("WHAT_COLOR", htmlspecialchars(DBi::$con->real_escape_string($_POST['g0'])));


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=special">
                           <a href="cp_home.php?mode=special">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }
 }
else {
    go_to("index.php");
}
?>