<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");

if ($CPMlevel == 4) {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=msg&type=insert">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['welcome_msg'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list">'.$lang['admin']['active_welcome_message'].'</td>
		<td class="userdetails_data"><input type="radio" value="1" name="MSG" '.check_radio($MSG, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;
        <input type="radio" value="0" name="MSG" '.check_radio($MSG, "0").'>'.$lang['add_cat_forum']['no'].'</td>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['part1'].'</nobr></td>
		<td class="middle"><input type="text"  name="FORUM_MSG" size="50" value="'.$FORUM_MSG.'"><nobr>&nbsp;&nbsp;&nbsp;&nbsp;'.$forum_title.'</nobr></td>
		
	</tr>
		</tr>
		<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['part2'].'</nobr></td>
		<td class="middle"><input type="text"  name="FORUM_MSG1" size="50" value="'.$FORUM_MSG1.'"><nobr>&nbsp;&nbsp;&nbsp;&nbsp;'.$lang['admin']['from_here'].'</nobr></td>

		</tr>
	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
';
echo'
</form>
</table>
</center>';
 }

 if ($type == "insert") {
updata_mysql("MSG", $_POST['MSG']);
updata_mysql("FORUM_MSG", htmlspecialchars(DBi::$con->real_escape_string($_POST['FORUM_MSG'])));
updata_mysql("FORUM_MSG1", htmlspecialchars(DBi::$con->real_escape_string($_POST['FORUM_MSG1'])));

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=msg">
                           <a href="cp_home.php?mode=msg">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
 }
else {
    go_to("index.php");
}
?>