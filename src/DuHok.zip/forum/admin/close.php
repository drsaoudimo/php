<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");


if ($CPMlevel == 4) {

if ($method == "close") {
 if ($type == "") {
echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=close&method=close&type=insert_data">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['forum_status'].'</nobr></td>	
		    <tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['forum_status'].'</nobr></td>
		<td class="userdetails_data"><input type="radio" value="1" name="forum_status" '.check_radio($forum_status, "1").'>'.$lang['admin']['close'].'&nbsp;&nbsp;
        <input type="radio" value="0" name="forum_status" '.check_radio($forum_status, "0").'>'.$lang['admin']['open'].'</td>
	</tr>
	 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {

$Admin_ForumStatus = $_POST["forum_status"];
    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {
updata_mysql("FORUM_STATUS", $Admin_ForumStatus);


                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=close&method=close">
                           <a href="cp_home.php?mode=close&method=close">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }
 }
if ($method == "msg") {
 if ($type == "") {
echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="1" width="80%">
<form method="post" action="cp_home.php?mode=close&method=msg&type=insert_data">
		<td class="cat" colspan="2"><nobr>'.$lang['admin']['lock_message'].'</nobr></td>	
	</tr>

<tr class="fixed">
<td class="list"><nobr>'.$lang['admin']['message_lock'].'</nobr></td>
			<td class="middle">
<textarea name="close" style="HEIGHT:169;WIDTH: 646;FONT-WEIGHT: bold;FONT-SIZE: 15px;BACKGROUND-COLOR: #91BBC9;COLOR: #000000;FONT-FAMILY: Times New Roman" cols="1" rows="999">'.$close.'</textarea></td>
</tr>

			<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {
    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {
updata_mysql("close", htmlspecialchars(DBi::$con->real_escape_string($_POST['close'])));

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=close&method=msg">
                           <a href="cp_home.php?mode=close&method=msg">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
 }
 } else {
	go_to("index.php"); 
 }
?>