<?php
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");

if ($CPMlevel == 4) {

 if ($type == "") {

echo'
<center>

<table class="grid" border="0" cellspacing="1" cellpadding="2" width="96%">
<form method="post" action="cp_home.php?mode=ads&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="8"><nobr>'.$lang['admin']['ads1'].'</nobr></td>
			</tr>
				<td class="optionheader_selected" colspan="8"><nobr>'.$lang['admin']['ads1_description'].'</nobr></td>
	</tr>
	    <tr class="fixed">
		<td class="list"><nobr>'.$lang['add_cat_forum']['active'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="1" name="ad" '.check_radio($add, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="0" name="ad" '.check_radio($add, "0").'>'.$lang['add_cat_forum']['no'].'
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link_photo'].'</nobr></td>
		<td class="list" colspan="5"><input type="text" name="ad3" size="60" value="'.$ad3.'">
	</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="ad1" size="60" value="'.$ad1.'"></td>
	</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link_name'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="ad2" size="60" value="'.$ad2.'">
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_height'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="ad4" size="60" value="'.$ad4.'"></td>
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_width'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="ad5" size="60" value="'.$ad5.'"></td>
	</tr>';
	    echo'
<tr class="fixed">
		<td class="userdetails_data"><nobr>'.$lang['add_cat_forum']['site'].'</nobr></td>
		<td class="userdetails_data"><select class="insidetitle" name="ad6" size="1">
			<option value="left" '.check_select($ad6, "left").'>'.$lang['admin']['ads_left'].'</option>
			<option value="center" '.check_select($ad6, "center").'>'.$lang['admin']['ads_center'].'</option>
			<option value="right" '.check_select($ad6, "right").'>'.$lang['admin']['ads_right'].'</option>
	</select></td>
	</tr>
		<tr class="fixed">
		<td class="cat" colspan="8"><nobr>'.$lang['admin']['ads2'].'</nobr></td>
					</tr>
				<td class="optionheader_selected" colspan="8"><nobr>'.$lang['admin']['ads2_description'].'</nobr></td>

	</tr>
	    <tr class="fixed">
		<td class="list"><nobr>'.$lang['add_cat_forum']['active'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="1" name="pb" '.check_radio($pb, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="0" name="pb" '.check_radio($pb, "0").'>'.$lang['add_cat_forum']['no'].'
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link_photo'].'</nobr></td>
		<td class="list" colspan="5"><input type="text" name="pb3" size="60" value="'.$pb3.'">
	</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pb1" size="60" value="'.$pb1.'"></td>
	</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link_name'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pb2" size="60" value="'.$pb2.'">
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_height'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pb4" size="60" value="'.$pb4.'"></td>
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_width'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pb5" size="60" value="'.$pb5.'"></td>
	</tr>';
	    echo'
<tr class="fixed">
		<td class="userdetails_data"><nobr>'.$lang['add_cat_forum']['site'].'</nobr></td>
		<td class="userdetails_data"><select class="insidetitle" name="pb6" size="1">
			<option value="left" '.check_select($pb6, "left").'>'.$lang['admin']['ads_left'].'</option>
			<option value="center" '.check_select($pb6, "center").'>'.$lang['admin']['ads_center'].'</option>
			<option value="right" '.check_select($pb6, "right").'>'.$lang['admin']['ads_right'].'</option>
	</select></td>
	</tr>
		<td class="cat" colspan="8"><nobr>'.$lang['admin']['ads3'].'</nobr></td>
					</tr>
				<td class="optionheader_selected" colspan="8"><nobr>'.$lang['admin']['ads3_description'].'</nobr></td>

	    <tr class="fixed">
		<td class="list"><nobr>'.$lang['add_cat_forum']['active'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="1" name="pub" '.check_radio($pub, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="0" name="pub" '.check_radio($pub, "0").'>'.$lang['add_cat_forum']['no'].'
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link_photo'].'</nobr></td>
		<td class="list" colspan="5"><input type="text" name="pub3" size="60" value="'.$pub3.'">
	</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pub1" size="60" value="'.$pub1.'"></td>
	</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link_name'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pub2" size="60" value="'.$pub2.'">
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_height'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pub4" size="60" value="'.$pub4.'"></td>
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_width'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pub5" size="60" value="'.$pub5.'"></td>
	</tr>';
	    echo'
<tr class="fixed">
		<td class="userdetails_data"><nobr>'.$lang['add_cat_forum']['site'].'</nobr></td>
		<td class="userdetails_data"><select class="insidetitle" name="pub6" size="1">
			<option value="left" '.check_select($pub6, "left").'>'.$lang['admin']['ads_left'].'</option>
			<option value="center" '.check_select($pub6, "center").'>'.$lang['admin']['ads_center'].'</option>
			<option value="right" '.check_select($pub6, "right").'>'.$lang['admin']['ads_right'].'	</option>
	</select></td>
	</tr>
		<td class="cat" colspan="8"><nobr>'.$lang['admin']['ads4'].'</nobr></td>
					</tr>
				<td class="optionheader_selected" colspan="8"><nobr>'.$lang['admin']['ads4_description'].'</nobr></td>

	    <tr class="fixed">
		<td class="list"><nobr>'.$lang['add_cat_forum']['active'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="1" name="pubs" '.check_radio($pubs, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="0" name="pubs" '.check_radio($pubs, "0").'>'.$lang['add_cat_forum']['no'].'
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link_photo'].'</nobr></td>
		<td class="list" colspan="5"><input type="text" name="pubs3" size="60" value="'.$pubs3.'">
	</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pubs1" size="60" value="'.$pubs1.'"></td>
	</tr>

 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_link_name'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pubs2" size="60" value="'.$pubs2.'">
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_height'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pubs4" size="60" value="'.$pubs4.'"></td>
	</tr>
	 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['admin']['ads_width'].'</nobr></td>
		<td class="middle" colspan="5"><input type="text" name="pubs5" size="60" value="'.$pubs5.'"></td>
	</tr>';
	    echo'
<tr class="fixed">
		<td class="userdetails_data"><nobr>'.$lang['add_cat_forum']['site'].'</nobr></td>
		<td class="userdetails_data"><select class="insidetitle" name="pubs6" size="1">
			<option value="left" '.check_select($pubs6, "left").'>'.$lang['admin']['ads_left'].'</option>
			<option value="center" '.check_select($pubs6, "center").'>'.$lang['admin']['ads_center'].'</option>
			<option value="right" '.check_select($pubs6, "right").'>'.$lang['admin']['ads_right'].'</option>
	</select></td>
	</tr>

 	<tr class="fixed">
		<td align="middle" colspan="8"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="60"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("ad", $_POST['ad']);
updata_mysql("ad1", htmlspecialchars(DBi::$con->real_escape_string($_POST['ad1'])));
updata_mysql("ad2", htmlspecialchars(DBi::$con->real_escape_string($_POST['ad2'])));
updata_mysql("ad3", htmlspecialchars(DBi::$con->real_escape_string($_POST['ad3'])));
updata_mysql("ad4", htmlspecialchars(DBi::$con->real_escape_string($_POST['ad4'])));
updata_mysql("ad5", htmlspecialchars(DBi::$con->real_escape_string($_POST['ad5'])));
updata_mysql("ad6", $_POST['ad6']);
updata_mysql("pb", $_POST['pb']);
updata_mysql("pb1", htmlspecialchars(DBi::$con->real_escape_string($_POST['pb1'])));
updata_mysql("pb2", htmlspecialchars(DBi::$con->real_escape_string($_POST['pb2'])));
updata_mysql("pb3", htmlspecialchars(DBi::$con->real_escape_string($_POST['pb3'])));
updata_mysql("pb4", htmlspecialchars(DBi::$con->real_escape_string($_POST['pb4'])));
updata_mysql("pb5", htmlspecialchars(DBi::$con->real_escape_string($_POST['pb5'])));
updata_mysql("pb6", $_POST['pb6']);
updata_mysql("pub", $_POST['pub']);
updata_mysql("pub1", htmlspecialchars(DBi::$con->real_escape_string($_POST['pub1'])));
updata_mysql("pub2", htmlspecialchars(DBi::$con->real_escape_string($_POST['pub2'])));
updata_mysql("pub3", htmlspecialchars(DBi::$con->real_escape_string($_POST['pub3'])));
updata_mysql("pub4", htmlspecialchars(DBi::$con->real_escape_string($_POST['pub4'])));
updata_mysql("pub5", htmlspecialchars(DBi::$con->real_escape_string($_POST['pub5'])));
updata_mysql("pub6", $_POST['pub6']);
updata_mysql("pubs", $_POST['pubs']);
updata_mysql("pubs1", htmlspecialchars(DBi::$con->real_escape_string($_POST['pubs1'])));
updata_mysql("pubs2", htmlspecialchars(DBi::$con->real_escape_string($_POST['pubs2'])));
updata_mysql("pubs3", htmlspecialchars(DBi::$con->real_escape_string($_POST['pubs3'])));
updata_mysql("pubs4", htmlspecialchars(DBi::$con->real_escape_string($_POST['pubs4'])));
updata_mysql("pubs5", htmlspecialchars(DBi::$con->real_escape_string($_POST['pubs5'])));
updata_mysql("pubs6", $_POST['pubs6']);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="60"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=ads">
                           <a href="cp_home.php?mode=ads">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
} else {
go_to("index.php");	
}
?>