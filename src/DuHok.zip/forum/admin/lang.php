<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

@require_once("./session.php");
@require_once("./language/".$choose_language.".php");

if ($CPMlevel == 4) {

if ($method == "") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=lang&type=set">
	<tr class="fixed">
		<td class="cat" colspan="5"><nobr>'.$lang['temy_other']['lang_option'].'</nobr></td>
	</tr>';
 
        $ch_lang = DBi::$con->query("SELECT * FROM ".$Prefix."LANGUAGE ") or die (DBi::$con->error);
        $lang_num = mysqli_num_rows($ch_lang);

        if ($lang_num > 0) {

            $lang_i = 0;
            while ($lang_i < $lang_num) {

                $lang_id = mysqli_result($ch_lang, $lang_i, "L_ID");
                $lang_file_name = mysqli_result($ch_lang, $lang_i, "L_FILE_NAME");
                $lang_name = mysqli_result($ch_lang, $lang_i, "L_NAME");

                echo'
                <input type="hidden" name="lang_id[]" value="'.$lang_id.'">
	        	<tr class="fixed">
	        		<td class="cat"><nobr>'.$lang['temy_other']['lang_name'].'</nobr></td>
	        		<td class="middle"><input type="text" name="lang_name[]" size="15" value="'.$lang_name.'"></td>
                    <td class="cat"><nobr>'.$lang['temy_other']['lang_file_name'].'</nobr></td>
                    <td class="middle"><input type="text" name="lang_file[]" size="15" value="'.$lang_file_name.'"></td>
                    <td align="middle">
                    <table>
                        <tr>
                            <td class="optionsbar_menus">
                                <font size="3"><nobr><a href="cp_home.php?mode=lang&method=delete&id='.$lang_id.'&step='.$lang_file_name.'">'.$lang['temy_other']['delete_lang'].'</a></nobr></font>
                            </td>
                        </tr>
                    </table>
                    </td>
	        	</tr>';

            ++$lang_i;
            }
        }
        else {
            echo'
	        <tr class="fixed">
		        <td class="list_center" colspan="5"><br>'.$lang['temy_other']['no_langs'].'<br><br></td>
	        </tr>';
 
        }
		echo'
		<tr class="fixed">
		                    <td colSpan="5" align="middle">
                    <table>
                        <tr>
                            <td class="optionsbar_menus">
                                <font size="3"><nobr><a href="cp_home.php?mode=lang&method=add">'.$lang['temy_other']['add_new_lang'].'</a></nobr></font>
                            </td>
                        </tr>
                    </table>
                    </td>
		</tr>
		';
if ($lang_num > 0) {
    echo'
 	<tr class="fixed">
		<td align="middle" colspan="5"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>';
}
echo'
</form>
</table>
</center>';


 }

 if ($type == "set") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

$lang_id = $_POST["lang_id"];
$lang_name = $_POST["lang_name"];
$lang_file = $_POST["lang_file"];


$i_l = 0;
$f_l = 0;
$n_l = 0;
while($i_l < count($lang_id)) {

		$updatingLang = DBi::$con->query("UPDATE ".$Prefix."LANGUAGE SET L_FILE_NAME = '".$lang_file[$f_l]."', L_NAME = '".$lang_name[$n_l]."' WHERE L_ID = ".$lang_id[$i_l]." ");
        $n_l++;
        $f_l++;
        $i_l++;

}

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=lang">
                           <a href="cp_home.php?mode=lang">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}



if ($method == "add") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=lang&&method=add&type=set">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['temy_other']['add_new_lang'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>'.$lang['temy_other']['lang_name'].'</nobr></td>
		<td><input type="text" name="lang_name" size="20"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['temy_other']['lang_file_name'].'</nobr></td>
		<td><input type="text" dir="ltr" name="lang_file" size="20"></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';

 }

 if ($type == "set") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

$lang_name = $_POST["lang_name"];
$lang_file = $_POST["lang_file"];

     $query = "INSERT INTO ".$Prefix."LANGUAGE (L_ID, L_FILE_NAME, L_NAME) VALUES (NULL, ";
     $query .= " '$lang_file', ";
     $query .= " '$lang_name') ";

     DBi::$con->query($query, $connection) or die (DBi::$con->error);


                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['temy_other']['done_add_lang'].'..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=lang">
                           <a href="cp_home.php?mode=lang">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
}

if ($method == "lang") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=lang&method=lang&type=insert_data">
	</tr>
 	<tr class="fixed">
 			<td class="cat" colspan="4"><nobr>'.$lang['temy_other']['default_lang'].'</nobr></td>
 	<tr class="fixed">

		<td class="list"><nobr>'.$lang['temy_other']['default_lang'].'</nobr></td>
		<td class="middle" colspan="3">
		
        <select class="insidetitle" style="WIDTH: 150px" name="lang_name">';
        $ch_lang = DBi::$con->query("SELECT * FROM ".$Prefix."LANGUAGE ") or die (DBi::$con->error);
        $lang_num = mysqli_num_rows($ch_lang);

        if ($lang_num > 0) {

            $lang_i = 0;
            while ($lang_i < $lang_num) {

                $lang_id = mysqli_result($ch_lang, $lang_i, "L_ID");
                $lang_file_name = mysqli_result($ch_lang, $lang_i, "L_FILE_NAME");
                $lang_name = mysqli_result($ch_lang, $lang_i, "L_NAME");

                echo'<option value="'.$lang_file_name.'" '.check_select($default_language, $lang_file_name).'>'.$lang_name.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>';

            ++$lang_i;
            }
        }
        else {
            echo'<option value="">'.$lang['temy_other']['no_langs'].'</option>';
        }
        echo'
        </td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="4"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("DEFAULT_LANGUAGE", $_POST["lang_name"]);



                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=lang&method=lang">
                           <a href="cp_home.php?mode=lang&method=lang">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}

if ($method == "delete") {

DBi::$con->query("DELETE FROM " . $Prefix . "LANGUAGE WHERE L_ID = '$id' ") or die (DBi::$con->error);
updata_mysql("DEFAULT_LANGUAGE", "arabic");

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['temy_other']['done_delete_lang'].'..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=lang">
                           <a href="cp_home.php?mode=lang">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}
}

else {
    go_to("index.php");
}
?>
