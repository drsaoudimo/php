<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

require_once("./session.php");
require_once("./language/".$choose_language.".php");

if ($CPMlevel == 4) {

if ($method == "") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=style&type=set">
	<tr class="fixed">
		<td class="cat" colspan="5"><nobr>'.$lang['temy_other']['styles_option'].'</nobr></td>
	</tr>';
 
        $ch_style = DBi::$con->query("SELECT * FROM ".$Prefix."STYLE ") or die (DBi::$con->error);
        $style_num = mysqli_num_rows($ch_style);

        if ($style_num > 0) {

            $style_i = 0;
            while ($style_i < $style_num) {

                $style_id = mysqli_result($ch_style, $style_i, "S_ID");
                $style_file_name = mysqli_result($ch_style, $style_i, "S_FILE_NAME");
                $style_name = mysqli_result($ch_style, $style_i, "S_NAME");

                echo'
                <input type="hidden" name="style_id[]" value="'.$style_id.'">
	        	<tr class="fixed">
	        		<td class="cat"><nobr>'.$lang['temy_other']['style_name'] .'</nobr></td>
	        		<td class="middle"><input type="text" name="style_name[]" size="15" value="'.$style_name.'"></td>
                    <td class="cat"><nobr>'.$lang['temy_other']['style_file_name'].'</nobr></td>
                    <td class="middle"><input type="text" name="style_file[]" size="15" value="'.$style_file_name.'"></td>
                    <td align="middle">
                    <table>
                        <tr>
                            <td class="optionsbar_menus">
                                <font size="3"><nobr><a href="cp_home.php?mode=style&method=delete&id='.$style_id.'&step='.$style_file_name.'">'.$lang['temy_other']['delete_style'].'</a></nobr></font>
                            </td>
                        </tr>
                    </table>
                    </td>
	        	</tr>';

            ++$style_i;
            }
        }
        else {
            echo'
	        <tr class="fixed">
		        <td class="list_center" colspan="5"><br>'.$lang['temy_other']['no_styles'].'<br><br></td>
	        </tr>';
 
        }
        
    echo'
	<tr class="fixed">
       <td align="middle" colspan="5">
       <table>
           <tr>
               <td class="optionsbar_menus">
                   <font size="3"><a href="cp_home.php?mode=style&method=add">'.$lang['temy_other']['add_new_style'].'</a></font>
               </td>
           </tr>
       </table>
       </td>
	</tr>';
if ($style_num > 0) {
    echo'
 	<tr class="fixed">
		<td align="middle" colspan="5"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>';
}
echo'
</form>
</table>
</center>';


 }

 if ($type == "set") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

$style_id = $_POST["style_id"];
$style_name = $_POST["style_name"];
$style_file = $_POST["style_file"];


$i_s = 0;
$f_s = 0;
$n_s = 0;
while($i_s < count($style_id)) {

		$updatingStyle = DBi::$con->query("UPDATE ".$Prefix."STYLE SET S_FILE_NAME = '".$style_file[$f_s]."', S_NAME = '".$style_name[$n_s]."' WHERE S_ID = ".$style_id[$i_s]." ");
        $n_s++;
        $f_s++;
        $i_s++;

}

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=style">
                           <a href="cp_home.php?mode=style">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}



if ($method == "add") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=style&&method=add&type=set">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>'.$lang['temy_other']['add_new_style'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>'.$lang['temy_other']['style_name'].'</nobr></td>
		<td><input type="text" name="style_name" size="20"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>'.$lang['temy_other']['style_file_name'].'</nobr></td>
		<td><input type="text" dir="ltr" name="style_file" size="20"></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['temy_other']['add_a_style'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';

 }

 if ($type == "set") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

$style_name = DBi::$con->real_escape_string(htmlspecialchars($_POST["style_name"]));
$style_file = DBi::$con->real_escape_string(htmlspecialchars($_POST["style_file"]));

     $query = "INSERT INTO ".$Prefix."STYLE (S_ID, S_FILE_NAME, S_NAME) VALUES (NULL, ";
     $query .= " '$style_file', ";
     $query .= " '$style_name') ";

     DBi::$con->query($query, $connection) or die (DBi::$con->error);


                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=style">
                           <a href="cp_home.php?mode=style">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
}


if ($method == "delete") {

DBi::$con->query("DELETE FROM ".$Prefix."STYLE WHERE S_ID = '$id' ") or die (DBi::$con->error);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['temy_other']['done_delete_style'].'..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=style">
                           <a href="cp_home.php?mode=style">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}
 
 
}
else {
    go_to("index.php");
}
?>
