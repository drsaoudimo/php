<?
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/

if ($CPMlevel == 4) {

require_once("./session.php");
require_once("./language/".$choose_language.".php");
require_once("./converts.php");
echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['admin']['home'].'</nobr></td>
	</tr>
	<tr class="fixed">
		<td align="middle">
        <br>
        <font color="black">
        ---------------------------------------------------------------------------------
		 <br><br>
		';
		$version = file_get_contents("http://dahuk.info/version.js");
		$version_url = file_get_contents("http://dahuk.info/version_url.js");
		$forum_version = open_mysql("DUHOK_FORUM_VERSION");
		if($version == $forum_version) {
		echo'<font color="green" size="5">'.$lang['auto_update']['this_is_last_update'].'</font>';	
		} else {
		echo'<font color="red" size="5">'.$lang['auto_update']['there_are_new_version'].'<br><br><a target="plaquepreview" href="'.$version_url.'">'.$version.'</a><br><br><a href="cp_home.php?mode=update">'.$lang['auto_update']['click_here_to_auto_update'].'</a></font>';
		}
 		echo'
		<br><br>
		---------------------------------------------------------------------------------
        <br><br>
       '.$lang['admin']['welcome_to_forum'].' '.$forum_version.'
        <br><br>
        '.$lang['admin']['programming_by_dilovan'].'
        <br><br>
        '.$lang['admin']['developing_by_duhok_forum_team'].'
        <br> <br>
		---------------------------------------------------------------------------------
        <br><br>
        '.$lang['admin']['for_suppor'].'
        <br><br>
        '.$lang['admin']['visit_this_link'].'
        <br>
        <br>
        -- <a target="plaquepreview" href="http://dahuk.info"><font color="#cc0033">dahuk.info</font></a> --
        <br>
        <br>
		'.$lang['admin']['support_forum_on_startimes'].'
		<br>
		<br>
		-- <a target="plaquepreview" href="http://www.startimes.com/f.aspx?f=211"><font color="#cc0033">'.$lang['other']['forum_211'].'</font></a> --
        <br>
		<br>
		'.$lang['admin']['send_email_to_developing_team'].'
        <br><br>
        -- <a target="plaquepreview" href="mailto:admin@dahuk.info"><font color="#cc0033">admin@dahuk.info</font></a> --
        <br><br>
        ---------------------------------------------------------------------------------
		<br><br>
        <font face="Tahoma" color="black" style="FONT-SIZE: 11px">Copyright © DuHok Forum Team 2015 - 2016. All rights reserved</font>
        <br><br> 
		---------------------------------------------------------------------------------
</font>
        </td>
	</tr>
</table>
</center>';

} else {
go_to("index.php");
}
?>