<?php
/*/////////////////////////////////////////////////////////////////////////////////
// ############################################################################# //
// #                              Duhok Forum 2.1                              # //
// ############################################################################# //
// #                                                                           # //
// #                   --  DuHok Forum Is Free Software  --                    # //
// #                                                                           # //
// #      ================== Programming By Dilovan ====================       # //
// #                                                                           # //
// #               Copyright © 2015-2016 Dilovan. All Rights Reserved          # //
// #                                                                           # //
// #                       Developing By DuHok Forum Team :                    # //
// #                                                                           # //
// #     Programming Team : DevMedoo & Temy & Dr Zikoo && General BouGassa     # //
// #                                                                           # //
// #        Following Team : M Haroun & Dr Bad-r & reda_cool & Dz-OMAR         # //
// #                                                                           # //
// #          Thanks To All Who Helped Us To Get This Version Of DuHok         # //
// #                                                                           # //
// # ------------------------------------------------------------------------- # //
// # ------------------------------------------------------------------------- # //
// #                                                                           # //
// # If You Want Any Support Vist Down Address:-                               # //
// # Email: admin@dahuk.info                                                   # //
// # Site: http://www.startimes.com/f.aspx?mode=f&f=211                        # //
// ############################################################################# //
/////////////////////////////////////////////////////////////////////////////////*/
  require_once("./engine/market_function.php");
  require_once("./engine/function.php");
  require_once("./language/".$choose_language.".php");
echo'<script language="javascript" src="./language/'.$choose_language.'.js"></script>'; 
  if ($CPMlevel == 4) {

$question = icons($icon_question, $lang['admin']['click_here_to_know_what_this'], "");

  if ($method == "market") {

 if ($type == "") {
echo'
	<center>
	<table class="grid" border="0" cellspacing="1" cellpadding="3" width="80%">
	<form name="list_option" method="post" action="cp_home.php?mode=market&method=market&type=insert_options">
		<tr class="fixed">
			<td class="cat" colspan="2"><nobr>'.$lang['admin']['market_options'].'</nobr></td>
		</tr>
	 	<tr class="fixed">
			<td class="list"><nobr>'.$lang['admin']['active_market'].'</nobr></td>
			<td class="list"><input type="radio" value="1" name="active_market" '.check_radio($active_market, "1").'>'.$lang['add_cat_forum']['yes'].'&nbsp;&nbsp;&nbsp; <input type="radio" value="0" name="active_market" '.check_radio($active_market, "0").'>'.$lang['add_cat_forum']['no'].'</td>
		</tr>
	 	<tr class="fixed">
			<td class="list"><nobr>'.$lang['admin']['dollar_cur'].'</nobr></td>
			<td class="list"><input class="small" type="text" size="1" name="dollar_cur" value="'.$dollar_cur.'"></td>
		</tr>		
	 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['admin']['insert_info_admin'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
		</tr>
	</form>
	</table>
	</center>';
}


 if ($type == "list") {
	 echo'
	 <center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="85%">
<tr class="fixed">
		<td class="cat" colspan="24"><nobr>'.$lang['admin']['sell_list'].'</nobr></td>
	</tr>
<tr class="fixed">
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_number'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_name'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_description'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_author'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_photo'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_date'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_status'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_buyer'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_buyer_date'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_dollar'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_sell'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_options'].'</td>
	</tr>
';

$sql = DBi::$con->query("SELECT * FROM ".prefix."MEMBERS_MARKET ORDER BY DATE");
$num = mysqli_num_rows($sql);
$x = 0;
while($x < $num) {
			$id = mysqli_result($sql, $x, "ID");
			$name = market("NAME", $id);
			$description = market("DESCRIPTION", $id);
			$desc = strip_tags(cutstr($description, 20));
			$img = market("IMG", $id);
			$author = market("AUTHOR", $id);
			$date = market("DATE", $id);
			$customer = market("CUSTOMER", $id);
			$status = market("STATUS", $id);
			$buy_date = market("BUY_DATE", $id);
			$dollar = market("DOLLAR", $id);			
			$buy_text = market("BUY_TEXT", $id);
			$buy_text_desc = strip_tags(cutstr($buy_text, 20));
			if($status == 1) {
			$status_msg = $lang['admin']['for_sale'];
			}
			if($status == 0) {
			$status_msg = $lang['admin']['sold'];
			}
		
			
echo '<tr class="fixed">
		<td class="f1" colspan="2" align="center"><nobr>'.$id.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr><a target="plaquepreview" href="index.php?mode=member&id='.$author.'&type=market&market='.$id.'">'.$name.'</a></nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$desc.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.link_profile(member_name($author),$author).'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr><a target="plaquepreview" href="'.$img.'"><img border="0" src="./images/icons/icons_camera.gif"></a></nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.normal_time($date).'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$status_msg.'</nobr></td>';
		if($status == 0) {
			echo'
		<td class="f1" colspan="2" align="center"><nobr>'.link_profile(member_name($customer),$customer).'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.normal_time($buy_date).'</nobr></td>
		';
		} else {
					echo'
		<td class="f1" colspan="2" align="center"><nobr>--</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>--</nobr></td>
		';	
		}	
		echo'
		<td class="f1" colspan="2" align="center"><nobr>'.$dollar.' '.$dollar_cur.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$buy_text_desc.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr></nobr><a href="./cp_home.php?mode=market&method=market&type=edit&id='.$id.'">'.icons($icon_edit, $lang['admin']['edit_sell']).'</a>&nbsp;&nbsp;<a href="cp_home.php?mode=market&method=market&type=delete&id='.$id.'" onclick="return confirm(\''.$lang['admin']['confirm_delete_sell'].'\');">'.icons($icon_trash, $lang['admin']['delete_sell']).'</a></td>

	</tr>';
++$x;
	}
echo'</table></center>';
}

 if ($type == "list_forum") {
	 echo'
	 <center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="85%">
<tr class="fixed">
		<td class="cat" colspan="23"><nobr>'.$lang['admin']['admin_market_list'].'</nobr></td>
	</tr>
<tr class="fixed">
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_number'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_name'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_description'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_photo'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_date'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_status'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_customer_number'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_customer'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_dollar'].'</td>
		<td class="optionheader_selected" colSpan="2">'.$lang['admin']['sell_type'].'</td>
		<td class="optionheader_selected" colSpan="2"><a href="./cp_home.php?mode=market&method=market&type=admin_add">'.icons($folder_new, $lang['admin']['sell_add']).'</a></td>
	</tr>
';

$sql = DBi::$con->query("SELECT * FROM ".prefix."ADMIN_MARKET ORDER BY DATE");
$num = mysqli_num_rows($sql);
$x = 0;
while($x < $num) {
			$id = mysqli_result($sql, $x, "ID");
			$name = admin_market("NAME", $id);
			$description = admin_market("DESCRIPTION", $id);
			$desc = strip_tags(cutstr($description, 20));
			$img = admin_market("IMG", $id);
			$author = admin_market("AUTHOR", $id);
			$date = admin_market("DATE", $id);
			$customer = admin_market("CUSTOMER", $id);
			$customer_number = admin_market("CUSTOMER_NUMBER", $id);
			$status = admin_market("STATUS", $id);
			$buy_date = admin_market("BUY_DATE", $id);
			$dollar = admin_market("DOLLAR", $id);			
			$type = admin_market("TYPE", $id);
			if($type == 1) {
			$type_msg = $lang['admin']['special_medal'];
			}
			if($type == 2) {
			$type_msg = $lang['admin']['special_points'];
			}
			if($status == 1) {
			$status_msg = $lang['admin']['for_sale'];
			}
			if($status == 0) {
			$status_msg = $lang['admin']['sold'];
			}
		
			
echo '<tr class="fixed">
		<td class="f1" colspan="2" align="center"><nobr>'.$id.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr><a target="plaquepreview" href="index.php?mode=social&type=market&market='.$id.'">'.$name.'</a></nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$desc.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr><a target="plaquepreview" href="'.$img.'"><img border="0" src="./images/icons/icons_camera.gif"></a></nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.normal_time($date).'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$status_msg.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$customer_number.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$customer.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$dollar.' '.$dollar_cur.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr>'.$type_msg.'</nobr></td>
		<td class="f1" colspan="2" align="center"><nobr></nobr><a href="./cp_home.php?mode=market&method=market&type=admin_edit&id='.$id.'">'.icons($icon_edit, $lang['admin']['edit_sell']).'</a>&nbsp;&nbsp;<a href="cp_home.php?mode=market&method=market&type=admin_delete&id='.$id.'" onclick="return confirm(\''.$lang['admin']['confirm_delete_sell'].'\');">'.icons($icon_trash, $lang['admin']['delete_sell']).'</a></td>

	</tr>';
++$x;
	}
echo'</table></center>';
}

if ($type == "admin_add") {
	 $chk_type = DBi::$con->real_escape_string(htmlspecialchars($_GET["chk_type"]));		

?>

<script>

			function chk_type(type){
				type = type.options[type.selectedIndex].value;
				if (type > 0){
					document.location = "cp_home.php?mode=market&method=market&type=admin_add&chk_type="+type;
				}
				else{
					return;
				}
			}
			
						function replace_title(new_text){

					document.sell_info.name.value = new_text;
				
			}
			function submit_form(){
				if (sell_info.name.value.length < 5){
					confirm(enter_sell_name);
					return;
				}	
				
				if (sell_info.description.value.length < 5){
					confirm(enter_sell_desc);
					return;
				}	
				if (sell_info.img.value.length < 5){
					confirm(enter_sell_photo);
					return;
				}
				if (sell_info.dollar.value.length == 0){
					confirm(enter_sell_dollar);
					return;
				}
			if (sell_info.customer_number.value.length == 0){
					confirm(enter_sell_customer_number);
					return;
				}				
				<?php if($chk_type == 1) { ?>
				
			if (sell_info.medal_id.value.length == 0){
					confirm(enter_sell_medal_id);
					return;
				}				
				
				<?php } if($chk_type == 2) { ?>
				
			if (sell_info.special_points_id.value.length == 0){
					confirm(enter_sell_points_id);
					return;
				}				
		
				<?php } ?>				
			
			sell_info.submit();
			}			

</script>

<?php

echo'<center>
                 <table width="1024" border="0" cellspacing="0" cellpadding="0"><tbody>';
		
	  
				  
				  echo'
		<center>
		<table cellSpacing="1" cellPadding="4" width="400" bgColor="gray" border="0">
	<form name="sell_info" method="post" action="cp_home.php?mode=market&method=market&type=insert_admin_add">
		<br><tr class="fixed">
				<td class="cat" colSpan="4"><nobr>'.$lang['admin']['add_new_sell'].'</nobr></td>
			</tr>
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_name'].': </nobr></td>
				<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 400px" name="name">
				<input class="insidetitle" onclick="replace_title(\'\');" type="button" value="X">
';
				echo'
				</td>
			</tr>
						<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_description'].': </nobr></td>
				<td class="list" colSpan="3">
				<textarea name="description" cols="55" rows="5"></textarea>
				<nobr></td>
		</tr>

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_link_photo'].': </nobr></td>
				<td class="list"  colSpan="3">
				<input name="img" size="55">
				<nobr></td>
		</tr>	

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_status'].': </nobr></td>
				<td class="list" colSpan="3">
				<font color="green">'.$lang['admin']['for_sale'].'</font>
				<nobr></td>
		</tr>
		
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_customer_number'].': </nobr></td>
				<td class="list" colSpan="3">
				<input class="insidetitle" style="WIDTH: 400px" name="customer_number">
				<nobr></td>
		</tr>

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_type'].': </nobr></td>
				<td class="list" colSpan="3">
				<select name="type" style="WIDTH:300px" onchange="chk_type(this)">
				';
				if($chk_type == "") {
				echo'<option value="0">'.$lang['admin']['select_sell_type'].'</option>';
				}
				if($chk_type == "" or $chk_type == 1 or $chk_type == 2) {
				echo'
				<option value="1" '.check_select($chk_type, 1).'>'.$lang['admin']['special_medal'].'</option>
				<option value="2" '.check_select($chk_type, 2).'>'.$lang['admin']['special_points'].'</option>
				';
				}
				echo'
				</select>
				<nobr></td>
		</tr>';
if($chk_type == 1) {
echo'

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_medal_id'].': </nobr></td>
				<td class="list" colSpan="3">
				<input name="medal_id" size="10">&nbsp;&nbsp;&nbsp;<font color="red" size="-1">'.$lang['admin']['sell_medal_id_description'].'</font>
				<nobr></td>
		</tr>	

		';
}
if($chk_type == 2) {
echo'

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_points_id'].': </nobr></td>
				<td class="list" colSpan="3">
				<input name="special_points_id" size="10">&nbsp;&nbsp;&nbsp;<font color="red" size="-1">'.$lang['admin']['sell_points_id_description'].'</font>
				<nobr></td>
		</tr>	
			
		
		';
}

		echo'
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_dollar'].': </nobr></td>
				<td class="list" colSpan="3">
				<input name="dollar" size="10" value="0">&nbsp;<font color="black" size="3">'.$dollar_cur.'</font>&nbsp;&nbsp;&nbsp;<font size="2" color="red">'.$lang['admin']['sell_dollar_description'].'</font>
				<nobr></td>
		</tr>				
			
			<tr class="fixed">
				<td class="list_center" colSpan="5"><input class="youcha" onmouseover="this.className=\'youcha youchahove\';" onmouseout="this.className=\'youcha\';" type="button" onclick="submit_form()" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="youcha" onmouseover="this.className=\'youcha youchahove\';" onmouseout="this.className=\'youcha\';" type="reset" value="'.$lang['profile']['reset_info'].'"></td>
			</tr>
		</form>
		</table>
		</center><br>';
		
	
 
}


if ($type == "admin_edit") {

if($id != "") {

echo'<center>
                 <table width="1024" border="0" cellspacing="0" cellpadding="0"><tbody>';
				 
				 				  ?>
				  		<script language="javascript">
						function replace_title(new_text){

					document.sell_info.name.value = new_text;
				
			}
			function submit_form(){
				if (sell_info.name.value.length < 5){
					confirm(enter_sell_name);
					return;
				}
				if (sell_info.description.value.length < 5){
					confirm(enter_sell_desc);
					return;
				}	
				if (sell_info.img.value.length < 5){
					confirm(enter_sell_photo);
					return;
				}
				if (sell_info.dollar.value.length == 0){
					confirm(enter_sell_dollar);
					return;
				}
			if (sell_info.customer_number.value.length == 0){
					confirm(enter_sell_customer_number);
					return;
				}				
				<?php if(admin_market("TYPE", $id) == 1) { ?>
				
			if (sell_info.medal_id.value.length == 0){
					confirm(enter_sell_medal_id);
					return;
				}				
				
				<?php } if(admin_market("TYPE", $id) == 2) { ?>
				
			if (sell_info.special_points_id.value.length == 0){
					confirm(enter_sell_points_id);
					return;
				}				
			
				<?php } ?>				
			
			sell_info.submit();
			}
			


		</script>
				  <?
				  
			$sql = DBi::$con->query("SELECT * FROM ".prefix."ADMIN_MARKET WHERE ID = '$id'");
			$num = mysqli_num_rows($sql);
			$x = 0;
	  		while($x < $num){
			$id = mysqli_result($sql, $x, "ID");
			$name = admin_market("NAME", $id);
			$description = admin_market("DESCRIPTION", $id);
			$desc = strip_tags(cutstr($description, 40));
			$img = admin_market("IMG", $id);
			$author = admin_market("AUTHOR", $id);
			$date = admin_market("DATE", $id);
			$customer = admin_market("CUSTOMER", $id);
			$customer_number = admin_market("CUSTOMER_NUMBER", $id);			
			$status = admin_market("STATUS", $id);
			$buy_date = admin_market("BUY_DATE", $id);
			$dollar = admin_market("DOLLAR", $id);
			$type = admin_market("TYPE", $id);	
			$medal_id = admin_market("MEDAL_ID", $id);				
			$medal = gm("URL", $medal_id);
			$medal_days = gm("DAYS", $medal_id);
			$points = gm("POINTS", $medal_id);
			$special_points_id = admin_market("SPECIAL_POINTS_ID", $id);							
			$special_points = gm("POINTS", $special_points_id);
			
			
				  
				  echo'
		<center>
		<table cellSpacing="1" cellPadding="4" width="400" bgColor="gray" border="0">
	<form name="sell_info" method="post" action="cp_home.php?mode=market&method=market&type=insert_admin_edit">
	<input type="hidden" name="id" value="'.$id.'">
	
		<br><tr class="fixed">
				<td class="cat" colSpan="4"><nobr>'.$lang['admin']['edit_sell'].': '.$name.'</nobr></td>
			</tr>
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_name'].': </nobr></td>
				<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 400px" name="name" value="'.$name.'">
				<input class="insidetitle" onclick="replace_title(\'\');" type="button" value="X">';
				echo'
				</td>
			</tr>
						<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_description'].': </nobr></td>
				<td class="list" colSpan="3">
				<textarea name="description" cols="55" rows="5">'.$description.'</textarea>
				<nobr></td>
		</tr>

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_link_photo'].': </nobr></td>
				<td class="list"  colSpan="3">
				<input name="img" value="'.$img.'" size="55">
				<nobr></td>
		</tr>	

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_status'].': </nobr></td>
				<td class="list" colSpan="3">';
				if($status == 1) {
				echo'
				<font color="green">'.$lang['admin']['for_sale'].'</font>
				';
				}
				if($status == 0) {
				echo'
				<font color="red">'.$lang['admin']['sold'].'</font>
				';
				}
				echo'
				<nobr></td>
		</tr>
		
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_customer_number'].': </nobr></td>
				<td class="list" colSpan="3">
				<input class="insidetitle" style="WIDTH: 400px" name="customer_number" value="'.$customer_number.'">
				<nobr></td>
		</tr>

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_type'].': </nobr></td>
				<td class="list" colSpan="3">
				';
				if($type == 1) {
				echo $lang['admin']['special_medal'];
				}
				if($type == 2) {
				echo $lang['admin']['special_points'];
				}
				echo'
				<nobr></td>
		</tr>';
if($type == 1) {
echo'

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_medal_id'].': </nobr></td>
				<td class="list" colSpan="3">
				<input name="medal_id" value="'.$medal_id.'" size="10">&nbsp;&nbsp;&nbsp;<font color="red" size="-1">'.$lang['admin']['sell_medal_id_description'].'</font>
				<nobr></td>
		</tr>	

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_medal_photo'].': </nobr></td>
				<td class="list" colSpan="3">
				<img border="0" src="'.$medal.'">
				<nobr></td>
		</tr>			
	
		
		';
		
}
if($type == 2) {
echo'

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_points_id'].': </nobr></td>
				<td class="list" colSpan="3">
				<input name="special_points_id" value="'.$special_points_id.'" size="10">&nbsp;&nbsp;&nbsp;<font color="red" size="-1">'.$lang['admin']['sell_points_id_description'].'</font>
				<nobr></td>
		</tr>	
		
		
		';
}
		echo'
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_dollar'].': </nobr></td>
				<td class="list" colSpan="3">
				<input name="dollar" value="'.$dollar.'" size="10" value="0">&nbsp;<font color="black" size="3">'.$dollar_cur.'</font>&nbsp;&nbsp;&nbsp;<font size="2" color="red">'.$lang['admin']['sell_dollar_description'].'</font>
				<nobr></td>
		</tr>				
			
			<tr class="fixed">
				<td class="list_center" colSpan="5"><input class="youcha" onmouseover="this.className=\'youcha youchahove\';" onmouseout="this.className=\'youcha\';" type="button" onclick="submit_form()" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="youcha" onmouseover="this.className=\'youcha youchahove\';" onmouseout="this.className=\'youcha\';" type="reset" value="'.$lang['profile']['reset_info'].'"></td>
			</tr>
		</form>
		</table>
		</center><br>';
		
	
 
		++$x;
		}
		}
}


if ($type == "edit") {
	 
	if($id != "") { 
echo'<center>
                 <table width="1024" border="0" cellspacing="0" cellpadding="0"><tbody>';
				 
				   ?>
				  		<script language="javascript">
									function replace_title(new_text){

					document.sell_info.name.value = new_text;
				
			}
			function submit_form(){
				if (sell_info.name.value.length < 5){
					confirm(enter_sell_name);
					return;
				}
				if (sell_info.description.value.length < 5){
					confirm(enter_sell_desc);
					return;
				}	
				if (sell_info.img.value.length < 5){
					confirm(enter_sell_photo);
					return;
				}
				if (sell_info.dollar.value.length == 0){
					confirm(enter_sell_dollar);
					return;
				}	
				if (sell_info.buy_text.value.length < 5){
					confirm(enter_sell);
					return;
				}					

			
			sell_info.submit();
			}
			


		</script>
				  <?
		
				  
	$sql = DBi::$con->query("SELECT * FROM ".prefix."MEMBERS_MARKET WHERE ID = '$id'");
	$num = mysqli_num_rows($sql);
	$x = 0;
	while($x < $num) {

			$id = mysqli_result($sql, $x, "ID");
			$name = market("NAME", $id);
			$description = market("DESCRIPTION", $id);
			$img = market("IMG", $id);
			$author = market("AUTHOR", $id);
			$date = market("DATE", $id);
			$customer = market("CUSTOMER", $id);
			$status = market("STATUS", $id);
			$buy_date = market("BUY_DATE", $id);
			$dollar = market("DOLLAR", $id);			
			$buy_text = market("BUY_TEXT", $id);		  
				  
				  echo'
		<center>
		<table cellSpacing="1" cellPadding="4" width="400" bgColor="gray" border="0">
	<form name="sell_info" method="post" action="cp_home.php?mode=market&method=market&type=insert_edit">
		<input type="hidden" name="id" value="'.$id.'">
		<input type="hidden" name="customer" value="'.$customer.'">
		<input type="hidden" name="author" value="'.$author.'">
		<br><tr class="fixed">
				<td class="cat" colSpan="4"><nobr>'.$lang['admin']['edit_sell'].' '.$name.'</nobr></td>
			</tr>
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_name'].': </nobr></td>
				<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 400px" name="name" value="'.$name.'">
				<input class="insidetitle" onclick="replace_title(\'\');" type="button" value="X">';
				echo'
				</td>
			</tr>
						<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_description'].': </nobr></td>
				<td class="list" colSpan="3">
				<textarea name="description" cols="55" rows="5">'.$description.'</textarea>
				<nobr></td>
		</tr>

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_link_photo'].': </nobr></td>
				<td class="list"  colSpan="3">
				<input name="img" value="'.$img.'" size="55">
				<nobr></td>
		</tr>

			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_photo'].': </nobr></td>
				<td class="list"  colSpan="3">
				<img border="0" src="'.$img.'">
				<nobr></td>
		</tr>		
			
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_author'].': </nobr></td>
				<td class="list"  colSpan="3">
				'.link_profile(member_name($author), $author).'
				<nobr></td>
		</tr>
		';
		if($status == 1) {
				$sell_status = '<font color="green">'.$lang['admin']['for_sale'].'</font>';
		}
		if($status == 0) {
				$sell_status = '<font color="red">'.$lang['admin']['sold'].'</font>';
		}	
		echo'
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_status'].': </nobr></td>
				<td class="list" colSpan="3">
				'.$sell_status.'
				<nobr></td>
		</tr>
			<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_dollar'].': </nobr></td>
				<td class="list" colSpan="3">
				<input name="dollar" value="'.$dollar.'" size="10" value="0">&nbsp;<font color="black" size="3">'.$dollar_cur.'</font>&nbsp;&nbsp;&nbsp;<font size="2" color="red">'.$lang['admin']['market_the_price'].'</font>
				<nobr></td>
		</tr>		
						<tr class="fixed">
				<td class="optionheader"><nobr>'.$lang['admin']['sell_sell'].': </nobr></td>
				<td class="list" colSpan="3">
				<textarea name="buy_text" cols="55" rows="5">'.$buy_text.'</textarea>
				<nobr></td>
		</tr>		
			
			<tr class="fixed">
				<td class="list_center" colSpan="5"><input class="youcha" onmouseover="this.className=\'youcha youchahove\';" onmouseout="this.className=\'youcha\';" type="button" onclick="submit_form()" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="youcha" onmouseover="this.className=\'youcha youchahove\';" onmouseout="this.className=\'youcha\';" type="reset" value="'.$lang['profile']['reset_info'].'"></td>
			
			</tr>
		</form>
		</table>
		</center><br>';
		
	
		
		++$x;
	}	



 }
}

if($type == "delete") {
	
if($id != "") {

DBi::$con->query("DELETE FROM ".prefix."MEMBERS_MARKET WHERE ID = '$id'");	


 echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['admin']['sell_delete'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=market&method=market&type=list">
                           <a href="cp_home.php?mode=market&method=market&type=list">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
					
	
}	
	
}


if($type == "admin_delete") {
	
if($id != "") {

DBi::$con->query("DELETE FROM ".prefix."ADMIN_MARKET WHERE ID = '$id'");	


 echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['admin']['sell_delete'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=market&method=market&type=list_forum">
                           <a href="cp_home.php?mode=market&method=market&type=list_forum">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
					
	
}	
	
}

 if ($type == "insert_options") {

updata_mysql("ACTIVE_MARKET", htmlspecialchars(DBi::$con->real_escape_string($_POST['active_market'])));
updata_mysql("DOLLAR_CUR", htmlspecialchars(DBi::$con->real_escape_string($_POST['dollar_cur'])));

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=market&method=market">
                           <a href="cp_home.php?mode=market&method=market">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}



 if ($type == "insert_edit") {
	 
			$id = DBi::$con->real_escape_string(htmlspecialchars($_POST['id']));
			$author = DBi::$con->real_escape_string(htmlspecialchars($_POST['author']));
			$customer = DBi::$con->real_escape_string(htmlspecialchars($_POST['customer']));
			$name = DBi::$con->real_escape_string(htmlspecialchars($_POST["name"]));
			$description = DBi::$con->real_escape_string(htmlspecialchars($_POST['description']));
			$img = DBi::$con->real_escape_string(htmlspecialchars($_POST['img']));
			$dollar = DBi::$con->real_escape_string(htmlspecialchars($_POST['dollar']));
			$buy_text = DBi::$con->real_escape_string(htmlspecialchars($_POST['buy_text']));
			
			
				DBi::$con->query("UPDATE ".prefix."MEMBERS_MARKET SET NAME = '$name', DESCRIPTION = '$description', IMG = '$img', DOLLAR = '$dollar', BUY_TEXT = '$buy_text' WHERE ID = '$id'");
				$subject = ''.$lang['admin']['edit_sell_message_subject'].' '.$name.'';
							if($customer != 0) {
				$message = ''.$lang['members']['members'].': '.link_profile(member_name($customer), $customer).'<br><br>'.$lang['admin']['edit_sell_message_part1'].' '.$name.' '.$lang['admin']['edit_sell_message_part2'].': '.link_profile(member_name($author), $author).'<br><br>'.$lang['admin']['edit_sell_message_part3'].'<br><br>'.$buy_text.'<br><br>'.$lang['admin']['edit_sell_message_part4'].'';
				$sendPm = "INSERT INTO ".$Prefix."PM (PM_ID, PM_MID, PM_TO, PM_FROM, PM_OUT, PM_SUBJECT, PM_MESSAGE, PM_DATE) VALUES (NULL, ";
				$sendPm .= " '1', ";
				$sendPm .= " '$customer', ";
				$sendPm .= " '1', ";
				$sendPm .= " '0', ";
				$sendPm .= " '$subject', ";
				$sendPm .= " '$message', ";
				$sendPm .= " '$date') ";
				@DBi::$con->query($sendPm, $connection) or die (DBi::$con->error);			
							}
							
                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['admin']['sell_edit'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=market&method=market&type=list">
                           <a href="cp_home.php?mode=market&method=market&type=list">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}



 if ($type == "insert_admin_edit") {
	 
			$id = DBi::$con->real_escape_string(htmlspecialchars($_POST['id']));
			$type = admin_market("TYPE", $id);
			$customer_number = DBi::$con->real_escape_string(htmlspecialchars($_POST['customer_number']));
			$name = DBi::$con->real_escape_string(htmlspecialchars($_POST["name"]));
			$description = DBi::$con->real_escape_string(htmlspecialchars($_POST['description']));
			$img = DBi::$con->real_escape_string(htmlspecialchars($_POST['img']));
			$dollar = DBi::$con->real_escape_string(htmlspecialchars($_POST['dollar']));
			if($type == 1) {
			$medal_id = DBi::$con->real_escape_string(htmlspecialchars($_POST['medal_id']));
			}
			if($type == 2) {
			$special_points_id = DBi::$con->real_escape_string(htmlspecialchars($_POST['special_points_id']));
			}
			if($type == 1) {
			$type_sale = "MEDAL_ID = '$medal_id'";
			}
			if($type == 2) {
			$type_sale = "SPECIAL_POINTS_ID = '$special_points_id'";
			}	
 if($type == "" or $customer_number == "" or $name == "" or $description == "" or $img == "" or $dollar == "0") {
			 echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font color="red" size="5"><br>'.$lang['admin']['not_do_all_options'].'</font><br><br>
                           <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
} else { 			
			DBi::$con->query("UPDATE ".prefix."ADMIN_MARKET SET NAME = '$name', DESCRIPTION = '$description', IMG = '$img', DOLLAR = '$dollar', CUSTOMER_NUMBER = '$customer_number', $type_sale WHERE ID = '$id'");
                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['admin']['sell_edit'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=market&method=market&type=list_forum">
                           <a href="cp_home.php?mode=market&method=market&type=list_forum">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
					}
}



 if ($type == "insert_admin_add") {
			$date = time();
			$type = DBi::$con->real_escape_string(htmlspecialchars($_POST['type']));
			$customer_number = DBi::$con->real_escape_string(htmlspecialchars($_POST['customer_number']));
			$name = DBi::$con->real_escape_string(htmlspecialchars($_POST["name"]));
			$description = DBi::$con->real_escape_string(htmlspecialchars($_POST['description']));
			$img = DBi::$con->real_escape_string(htmlspecialchars($_POST['img']));
			$dollar = DBi::$con->real_escape_string(htmlspecialchars($_POST['dollar']));
			if($type == 1) {
			$medal_id = DBi::$con->real_escape_string(htmlspecialchars($_POST['medal_id']));
			$medal = gm("URL", $medal_id);
			$medal_days = gm("DAYS", $medal_id);
			$points = gm("POINTS", $medal_id);
			}
			if($type == 2) {
			$special_points_id = DBi::$con->real_escape_string(htmlspecialchars($_POST['special_points_id']));
			$special_points = gm("POINTS", $special_points_id);
			}
			if($type == 1) {
			$type_sale = "TYPE, MEDAL_ID";
			}
			if($type == 2) {
			$type_sale = "TYPE, SPECIAL_POINTS_ID";
			}	
			$sql = "INSERT INTO ".prefix."ADMIN_MARKET (ID, NAME, DESCRIPTION, IMG , CUSTOMER_NUMBER, DOLLAR, DATE, $type_sale) VALUES (NULL, ";
			$sql .= " '$name', "; 
			$sql .= " '$description', "; 
			$sql .= " '$img', "; 
			$sql .= " '$customer_number', "; 
			$sql .= " '$dollar', "; 
			$sql .= " '$date', "; 
			if($type == 1) {
			$sql .= " '1', "; 
			$sql .= " '$medal_id' "; 
			}
			if($type == 2) {
			$sql .= " '2', "; 
			$sql .= " '$special_points_id' "; 
			}
			$sql .= " ) ";
			@DBi::$con->query($sql);
 if($type == "" or $customer_number == "" or $name == "" or $description == "" or $img == "" or $dollar == "0") {
			 echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font color="red" size="5"><br>'.$lang['admin']['not_do_all_options'].'</font><br><br>
                           <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
} else { 
			 echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['admin']['sell_added'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=market&method=market&type=list_forum">
                           <a href="cp_home.php?mode=market&method=market&type=list_forum">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
					}
}


  }
} else {
go_to("index.php");
}
?>